# FNOL Claims API - Complete Documentation

## 🎯 Overview

The FNOL (First Notice of Loss) Claims API provides immediate, AI-powered claim estimation using GPT-4o based on initial incident data. This enables Mendix to capture claim details and instantly receive cost estimates, severity assessments, and processing recommendations.

## 🚀 Quick Start

### Local Development

```bash
# 1. Set up environment
cd claims_api
cp .env.example .env

# Edit .env and add:
# - OPENAI_API_KEY (required for GPT-4o estimation)
# - ANTHROPIC_API_KEY (required for AI agents)
# - Other configuration as needed

# 2. Start with Docker
docker-compose up -d

# 3. Access API
# - API: http://localhost:8000
# - Swagger UI: http://localhost:8000/api/docs
# - ReDoc: http://localhost:8000/api/redoc

# 4. Run tests
python test_fnol_api.py
```

### Azure Production

```bash
# API Base URL
https://xyz-claims-api-production.azurewebsites.net/api/v1

# Swagger Documentation
https://xyz-claims-api-production.azurewebsites.net/api/docs
```

## 📡 API Endpoints

### 1. Submit FNOL with AI Estimation

**The primary endpoint for Mendix integration**

```http
POST /api/v1/claims/fnol
Authorization: Bearer {token}
Content-Type: application/json
```

**What it does:**
1. Captures complete FNOL data from Mendix
2. Validates policy and data completeness
3. Uses GPT-4o to generate comprehensive claim estimate
4. Returns estimated costs, severity, and next steps

**Request Body:**
```json
{
  "claimType": "ACCIDENT",
  "jurisdiction": "US",
  "locale": {
    "country": "US",
    "state": "FL"
  },
  "policyHolder": {
    "policyNumber": "POL-US-2024-123456",
    "firstName": "John",
    "lastName": "Smith",
    "contactInformation": {
      "primaryPhone": "+1-904-555-1234",
      "email": "john.smith@email.com",
      "preferredContactMethod": "PHONE"
    }
  },
  "incidentDetails": {
    "incidentDate": "2024-11-15T14:30:00Z",
    "incidentType": "MOTOR_VEHICLE_ACCIDENT",
    "incidentDescription": "Rear-ended at red light",
    "injuriesReported": ["Neck pain", "Headache"],
    "emergencyServicesInvolved": {
      "policeNotified": true,
      "ambulanceCalled": true
    }
  },
  "immediateActions": {
    "currentMedicalCare": {
      "receivingTreatment": true,
      "location": "Memorial Hospital ER"
    },
    "vehicleDetails": {
      "vehicleDriveable": false,
      "estimatedDamage": "MODERATE"
    }
  },
  "submissionMetadata": {
    "submittedBy": "John Smith",
    "submissionTimestamp": "2024-11-15T16:00:00Z",
    "channel": "MENDIX_PORTAL",
    "urgencyLevel": "URGENT"
  }
}
```

**Response (201 Created):**
```json
{
  "claimId": "550e8400-e29b-41d4-a716-446655440000",
  "claimNumber": "FNOL-2024-US-FL-550E8400",
  "status": "RECEIVED",
  "submissionTimestamp": "2024-11-15T16:00:00Z",
  "fnolData": { ... },
  "estimation": {
    "estimated_total_cost": {
      "amount": 12500.00,
      "currency": "USD",
      "range": {
        "min": 8750.00,
        "max": 18750.00
      }
    },
    "cost_breakdown": {
      "medical_expenses": 5000.00,
      "property_damage": 6000.00,
      "lost_wages": 1000.00,
      "other_costs": 500.00
    },
    "severity_assessment": "MODERATE",
    "confidence_score": 0.85,
    "estimated_settlement_time": "30-45 days",
    "recommended_reserve": {
      "amount": 15000.00,
      "justification": "Accounts for potential complications and additional medical treatment"
    },
    "risk_factors": [
      "Third party involved - liability determination needed",
      "Ongoing medical treatment - final costs uncertain",
      "Police report indicates other party at fault"
    ],
    "red_flags": [
      "None identified at this time"
    ],
    "next_steps": [
      "Request complete police report",
      "Obtain medical records from Memorial Hospital",
      "Contact third party insurer for liability",
      "Schedule vehicle damage assessment"
    ],
    "similar_claims_analysis": "Based on similar rear-end collisions with moderate vehicle damage and soft tissue injuries, typical settlement range is $10,000-$15,000",
    "special_considerations": [
      "Monitor for delayed injury symptoms",
      "Document all medical treatments",
      "Keep vehicle repair estimates"
    ]
  },
  "dataCompleteness": {
    "overall_score": 0.78,
    "categories": {
      "policyHolder": 0.80,
      "incidentDetails": 0.85,
      "immediateActions": 0.70,
      "thirdPartyInfo": 0.75,
      "consents": 0.80
    }
  },
  "nextSteps": [
    "Request additional documentation from claimant",
    "Contact treating physician for medical report",
    "Request hospital admission records"
  ],
  "estimatedProcessingTime": "5-7 business days"
}
```

### 2. Get Estimation Only (No Submission)

```http
POST /api/v1/claims/fnol/estimate-only
Authorization: Bearer {token}
```

**Use Cases:**
- Pre-submission cost estimates
- "What-if" scenarios for training
- Historical analysis

**Returns:** Estimation object only (no claim created)

### 3. Get FNOL Claim Details

```http
GET /api/v1/claims/fnol/{claimId}
Authorization: Bearer {token}
```

**Returns:** Complete FNOL claim with estimation

### 4. Update FNOL with Additional Data

```http
PUT /api/v1/claims/fnol/{claimId}/update
Authorization: Bearer {token}
Content-Type: application/json
```

**Use Case:** When additional details become available, re-run estimation

### 5. Get Data Enrichment Recommendations

```http
POST /api/v1/claims/fnol/{claimId}/enrich
Authorization: Bearer {token}
```

**Returns:** AI-powered recommendations for additional data to collect

**Response Example:**
```json
{
  "critical_missing_data": [
    "Detailed medical diagnosis from physician",
    "Complete police report",
    "Vehicle damage assessment photos"
  ],
  "recommended_documentation": [
    "Hospital admission records",
    "Ambulance transport report",
    "Witness statements"
  ],
  "suggested_questions": [
    "Was the airbag deployed?",
    "Any pre-existing injuries?",
    "Has claimant consulted an attorney?"
  ],
  "specialist_review_needed": false,
  "priority_level": "MEDIUM"
}
```

## 🔐 Authentication

### Getting Access Token

```http
POST /api/v1/auth/token
Content-Type: application/x-www-form-urlencoded

username=mendix_client
&password=your_password
&scope=claims:read claims:write
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

### Using Token

Include in all API requests:
```http
Authorization: Bearer {access_token}
```

Token expires in 30 minutes. Refresh using `/auth/refresh` endpoint.

## 📋 Data Models

### Required Fields at FNOL

**Minimum Required:**
- `claimType` - Type of claim (ACCIDENT, DISABILITY, etc.)
- `jurisdiction` - US or UK
- `policyHolder.policyNumber` - Policy identifier
- `policyHolder.firstName` - First name
- `policyHolder.lastName` - Last name
- `policyHolder.contactInformation.primaryPhone` - Contact number
- `incidentDetails.incidentDate` - When it happened
- `incidentDetails.incidentType` - Type of incident
- `incidentDetails.incidentDescription` - What happened
- `submissionMetadata.submittedBy` - Who is reporting
- `submissionMetadata.submissionTimestamp` - When submitted
- `submissionMetadata.channel` - How submitted

### Optional but Recommended

For better estimation accuracy:
- `incidentDetails.injuriesReported` - What injuries claimant reports
- `immediateActions.currentMedicalCare` - Current medical status
- `immediateActions.vehicleDetails` - Vehicle damage level
- `thirdPartyInformation` - Other party details
- `emergencyServicesInvolved` - Police/ambulance involvement

## 🎨 Estimation Logic

### GPT-4o Prompt Engineering

The API uses carefully crafted prompts to GPT-4o that consider:

**US-Specific Factors:**
- Average medical costs ($1,500-$3,000 for ER visits)
- Vehicle repair costs ($3,000-$10,000 for moderate damage)
- Lost wages calculations
- Liability limits and tort system
- State-specific regulations
- Attorney involvement likelihood

**UK-Specific Factors:**
- NHS coverage (most medical costs covered)
- Private medical treatment costs (if applicable)
- UK compensation culture (typically lower than US)
- No-fault system considerations
- Solicitor involvement patterns
- Personal injury tariffs

### Confidence Scoring

Estimation confidence (0-1) based on:
- Data completeness (more data = higher confidence)
- Claim type complexity
- Historical similar claims
- Uncertainty factors identified

**Confidence Levels:**
- 0.9-1.0: High confidence - comprehensive data
- 0.7-0.9: Good confidence - typical FNOL data
- 0.5-0.7: Moderate confidence - limited data
- <0.5: Low confidence - significant missing data

### Severity Assessment

- **MINOR**: < $5,000, no hospitalization, quick resolution
- **MODERATE**: $5,000-$25,000, ER visit, standard processing
- **SEVERE**: $25,000-$100,000, hospitalization, extended treatment
- **CATASTROPHIC**: > $100,000, major injuries, long-term impact

## 🔄 Integration Flow

### Recommended Mendix Flow

```
1. User completes FNOL form in Mendix
   ↓
2. Mendix validates data locally
   ↓
3. Mendix calls POST /api/v1/claims/fnol
   ↓
4. API returns immediate estimation (< 5 seconds)
   ↓
5. Mendix displays estimation to user
   ↓
6. Mendix stores claimId and claimNumber
   ↓
7. User confirms or adds more details
   ↓
8. If more details: PUT /api/v1/claims/fnol/{claimId}/update
   ↓
9. Mendix receives updated estimation
   ↓
10. Claim proceeds to processing
```

### Error Handling

**Common Errors:**

| Code | Error | Action |
|------|-------|--------|
| 401 | Unauthorized | Refresh token |
| 422 | Validation Error | Check required fields |
| 429 | Rate Limit | Wait and retry |
| 500 | Server Error | Retry with exponential backoff |

**Retry Strategy:**
```python
for attempt in range(3):
    try:
        response = submit_claim(data)
        break
    except RateLimitError:
        time.sleep(2 ** attempt)  # 1s, 2s, 4s
    except ServerError:
        if attempt == 2:
            # Escalate to support
            raise
```

## 📊 Response Time SLA

| Endpoint | Target | Max |
|----------|--------|-----|
| POST /fnol | < 3s | 10s |
| GET /fnol/{id} | < 1s | 3s |
| Estimation only | < 3s | 10s |

*Note: GPT-4o processing typically takes 2-5 seconds*

## 🧪 Testing

### Local Testing

```bash
# Start API
docker-compose up -d

# Run test suite
python test_fnol_api.py

# Expected output:
# ✓ US Accident FNOL: PASS
# ✓ UK Accident FNOL: PASS
# ✓ Estimation Only: PASS
```

### Postman Collection

Import OpenAPI spec from `/api/openapi.json` into Postman for interactive testing.

### Sample Payloads

See `FNOL_EXAMPLE_US.json` and `FNOL_EXAMPLE_UK.json` for complete examples.

## 🔒 Security

### Data Protection

- **PII Encryption**: SSN, DOB, account numbers encrypted at rest
- **TLS 1.3**: All data in transit encrypted
- **PII Masking**: PII stripped before sending to GPT-4o
- **Audit Logging**: All API calls logged for compliance

### Rate Limits

- **FNOL Submission**: 100 requests/minute per client
- **Estimation Only**: 100 requests/minute per client
- **Status Queries**: 500 requests/minute per client

### Compliance

- ✅ HIPAA Compliant (BAA required)
- ✅ GDPR Compliant (DPA required)
- ✅ SOC 2 Type II
- ✅ FCA Guidelines (UK)

## 📞 Support

### For Mendix Team

**Integration Issues:**
- Email: api-support@xyzconsulting.com
- Slack: #xyz-claims-api
- Response Time: < 4 hours (business hours)

**Production Issues:**
- PagerDuty: +1-XXX-XXX-XXXX
- Emergency Email: api-oncall@xyzconsulting.com
- Response Time: < 30 minutes (24/7)

### API Status

Real-time status: https://status.xyzconsulting.com

## 📈 Monitoring

### Mendix Dashboard Metrics

Track these metrics in your Mendix application:
- API response time (target: < 3s)
- Estimation confidence scores (aim for > 0.7)
- Error rate (target: < 1%)
- Claims by severity distribution
- Average estimated costs

### Webhooks (Optional)

Configure webhooks to receive:
- Claim status updates
- Estimation recalculations
- Missing data alerts

Contact XYZ team to enable webhooks.

## 🚀 Deployment

### Local Development
```bash
docker-compose up -d
```

### Azure Production
```bash
az webapp up --name xyz-claims-api-production --resource-group xyz-claims-rg
```

## 📝 Changelog

### v1.0.0 (January 2025)
- Initial FNOL API release
- GPT-4o integration for estimation
- US and UK jurisdiction support
- Comprehensive data completeness assessment
- Real-time AI-powered recommendations

---

**Document Version**: 1.0.0  
**Last Updated**: January 2025  
**For**: Mendix Integration Team  
**Contact**: Sathya (sathya@xyzconsulting.com)
