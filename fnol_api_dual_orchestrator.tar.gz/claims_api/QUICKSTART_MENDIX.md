# Quick Start Guide for Mendix Integration

## 🎯 What You Need Today

### 1. API Schema & Examples
✅ **File**: `MENDIX_API_SCHEMA.json`
- Complete JSON schema for all endpoints
- Real-world examples for US and UK claims
- Error codes and handling
- Rate limits and security requirements

### 2. Authentication Setup

#### Step 1: Get OAuth Token
```bash
curl -X POST https://api.xyzconsulting.com/api/v1/auth/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=mendix_client&password=YOUR_PASSWORD&scope=claims:read claims:write"
```

#### Step 2: Store Token
```json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

### 3. Test Claim Submission

#### US Accident Claim Example
```bash
curl -X POST https://api.xyzconsulting.com/api/v1/claims/text \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @us_accident_claim.json
```

**us_accident_claim.json:**
```json
{
  "claimType": "ACCIDENT",
  "jurisdiction": "US",
  "locale": {
    "country": "US",
    "state": "FL"
  },
  "policyHolder": {
    "policyNumber": "POL-US-2024-123456",
    "firstName": "John",
    "lastName": "Smith",
    "dateOfBirth": "1985-06-15",
    "gender": "MALE",
    "nationalIdentifier": {
      "type": "SSN",
      "value": "XXX-XX-1234"
    },
    "contactInformation": {
      "primaryPhone": "+1-904-555-1234",
      "email": "john.smith@email.com",
      "preferredLanguage": "en-US"
    },
    "address": {
      "street1": "123 Main Street",
      "city": "Jacksonville",
      "stateProvince": "FL",
      "postalCode": "32203",
      "country": "US"
    }
  },
  "incidentDetails": {
    "incidentDate": "2024-11-15T14:30:00Z",
    "incidentType": "ACCIDENT",
    "incidentDescription": "Motor vehicle collision",
    "workRelated": false
  },
  "submissionMetadata": {
    "submittedBy": "mendix_user_123",
    "submissionTimestamp": "2024-11-20T10:30:00Z",
    "channel": "MENDIX_PORTAL",
    "correlationId": "550e8400-e29b-41d4-a716-446655440000"
  }
}
```

**Expected Response:**
```json
{
  "claimId": "660e8400-e29b-41d4-a716-446655440001",
  "claimNumber": "CLM-2024-US-FL-001234",
  "status": "PROCESSING",
  "submissionTimestamp": "2024-11-20T10:30:00Z",
  "estimatedProcessingTime": "3-5 business days",
  "aiProcessing": {
    "agentAssigned": "claims_adjuster_ai",
    "automationLevel": "HYBRID",
    "confidenceScore": 0.87
  },
  "nextSteps": [
    {
      "action": "Awaiting medical documentation",
      "dueDate": "2024-11-25",
      "responsible": "PHYSICIAN"
    }
  ]
}
```

## 🔗 API Playground

### Development Environment
- **Base URL**: `http://localhost:8000/api/v1`
- **API Docs**: `http://localhost:8000/api/docs`
- **Test Credentials**: 
  - Username: `mendix_client`
  - Password: `secret`

### Staging Environment
- **Base URL**: `https://api-staging.xyzconsulting.com/api/v1`
- **Credentials**: Provided separately via secure channel

### Production Environment
- **Base URL**: `https://api.xyzconsulting.com/api/v1`
- **Credentials**: Contact XYZ API team

## 📋 Integration Checklist

### Pre-Integration
- [ ] Review `MENDIX_API_SCHEMA.json`
- [ ] Obtain OAuth credentials from XYZ team
- [ ] Set up test environment
- [ ] Test authentication flow

### Integration Development
- [ ] Implement OAuth 2.0 in Mendix
- [ ] Create REST service consumers
- [ ] Map FNOL data to API schema
- [ ] Implement error handling
- [ ] Add retry logic with exponential backoff
- [ ] Test with sample claims (US and UK)

### Testing Phase
- [ ] Submit test claims via API
- [ ] Verify claim status polling
- [ ] Test error scenarios
- [ ] Validate webhook integration
- [ ] Performance testing (rate limits)
- [ ] Security audit

### Go-Live
- [ ] Switch to production credentials
- [ ] Configure production webhook URL
- [ ] Enable monitoring and alerting
- [ ] Document integration for operations team
- [ ] Schedule go-live with XYZ team

## 🚨 Common Issues & Solutions

### Issue: 401 Unauthorized
**Solution**: Token expired or invalid. Refresh token using `/auth/refresh` endpoint.

### Issue: 422 Validation Error
**Solution**: Check request payload against schema. Common issues:
- Missing required fields
- Invalid date format (use ISO 8601)
- Invalid phone number format (E.164 recommended)

### Issue: 429 Too Many Requests
**Solution**: Implement rate limiting in your code. Respect `X-RateLimit-*` headers.

### Issue: 500 Internal Server Error
**Solution**: Check request payload and contact XYZ support with `X-Request-ID` header value.

## 📞 Support Contacts

### During Business Hours (EST)
- **Email**: api-support@xyzconsulting.com
- **Slack**: #xyz-claims-api
- **Phone**: +1-XXX-XXX-XXXX

### After Hours (Production Issues Only)
- **PagerDuty**: +1-XXX-XXX-XXXX
- **Emergency Email**: api-oncall@xyzconsulting.com

### Technical Lead
- **Name**: Sathya
- **Email**: sathya@xyzconsulting.com
- **Timezone**: EST

## 📊 API Status Page
Real-time status and incidents: `https://status.xyzconsulting.com`

## 🔐 Security Best Practices

1. **Never** hardcode credentials in your code
2. **Always** use HTTPS in production
3. **Store** tokens securely (encrypted)
4. **Rotate** credentials every 90 days
5. **Monitor** for unusual API activity
6. **Implement** request signing for sensitive data
7. **Use** correlation IDs for tracking

## 📈 Next Steps

1. **Today**: Review schema, test authentication
2. **This Week**: Implement basic claim submission
3. **Next Week**: Add OCR support, error handling
4. **Week 3**: Testing and refinement
5. **Week 4**: Production deployment

## 🎓 Additional Resources

- **Full API Documentation**: README.md
- **OpenAPI Spec**: http://localhost:8000/api/openapi.json
- **Postman Collection**: Available on request
- **Sample Code**: See `examples/` directory
- **Architecture Docs**: Contact XYZ team

---

**Questions?** Reach out to the XYZ API team anytime!
