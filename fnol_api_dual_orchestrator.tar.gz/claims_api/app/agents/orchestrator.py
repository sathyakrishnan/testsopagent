"""
AI Agent System for Claims Processing
Multi-agent orchestration using Anthropic Claude with specialized agents
"""
import anthropic
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import structlog
from app.core.config import settings
from app.models.schemas import (
    TextBasedClaimRequest, ClaimType, Jurisdiction,
    ClaimStatus, AIProcessing
)

logger = structlog.get_logger(__name__)


class ClaimAgent:
    """Base class for specialized claim processing agents"""
    
    def __init__(self, name: str, specialty: str):
        self.name = name
        self.specialty = specialty
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        
    async def process(self, claim_data: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Process claim data with AI analysis"""
        raise NotImplementedError


class MedicalReviewAgent(ClaimAgent):
    """Agent specialized in medical claim validation and analysis"""
    
    def __init__(self):
        super().__init__("MedicalReviewer", "Medical Claims Analysis")
        
    async def process(self, claim_data: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Analyze medical aspects of the claim"""
        
        prompt = f"""You are a medical claims specialist reviewing insurance claims for accuracy and completeness.

Claim Type: {claim_data.get('claimType')}
Jurisdiction: {claim_data.get('jurisdiction')}

Medical Information:
{json.dumps(claim_data.get('medicalInformation', {}), indent=2)}

Incident Details:
{json.dumps(claim_data.get('incidentDetails', {}), indent=2)}

Context: {context}

Analyze this claim and provide:
1. Medical necessity assessment
2. Diagnosis code validation (ICD-10/ICD-11)
3. Treatment appropriateness
4. Missing medical documentation
5. Red flags or inconsistencies
6. Confidence score (0-1)
7. Recommendation (APPROVE, REVIEW, DENY, REQUEST_INFO)

Respond in JSON format."""

        try:
            response = self.client.messages.create(
                model=settings.ANTHROPIC_MODEL,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            result = json.loads(response.content[0].text)
            logger.info("medical_review_completed", confidence=result.get('confidence_score'))
            return result
            
        except Exception as e:
            logger.error("medical_review_failed", error=str(e))
            return {
                "error": str(e),
                "confidence_score": 0.0,
                "recommendation": "MANUAL_REVIEW"
            }


class FraudDetectionAgent(ClaimAgent):
    """Agent specialized in fraud detection and risk assessment"""
    
    def __init__(self):
        super().__init__("FraudDetector", "Fraud Detection & Risk Analysis")
        
    async def process(self, claim_data: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Analyze claim for fraud indicators"""
        
        prompt = f"""You are a fraud detection specialist analyzing insurance claims for potential fraud.

Complete Claim Data:
{json.dumps(claim_data, indent=2, default=str)}

Analyze this claim for:
1. Temporal inconsistencies (dates, timelines)
2. Geographic anomalies
3. Claim amount irregularities
4. Pattern matching with known fraud cases
5. Medical billing red flags
6. Supporting documentation gaps
7. Risk score (0-100, where 100 is highest risk)
8. Specific risk factors identified

Consider:
- Is the claim amount reasonable for the diagnosis/treatment?
- Are there timing issues (e.g., policy recently activated)?
- Does the incident description align with medical findings?
- Are there duplicate claims or providers?

Respond in JSON format with risk_score, risk_factors array, and requires_investigation boolean."""

        try:
            response = self.client.messages.create(
                model=settings.ANTHROPIC_MODEL,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            result = json.loads(response.content[0].text)
            logger.info("fraud_detection_completed", risk_score=result.get('risk_score'))
            return result
            
        except Exception as e:
            logger.error("fraud_detection_failed", error=str(e))
            return {
                "error": str(e),
                "risk_score": 50,  # Default to medium risk on failure
                "requires_investigation": True
            }


class ComplianceAgent(ClaimAgent):
    """Agent specialized in regulatory compliance validation"""
    
    def __init__(self):
        super().__init__("ComplianceOfficer", "Regulatory Compliance")
        
    async def process(self, claim_data: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Validate claim against regulatory requirements"""
        
        jurisdiction = claim_data.get('jurisdiction')
        claim_type = claim_data.get('claimType')
        
        prompt = f"""You are a compliance officer ensuring insurance claims meet regulatory requirements.

Jurisdiction: {jurisdiction}
Claim Type: {claim_type}

Claim Data:
{json.dumps(claim_data, indent=2, default=str)}

Validate compliance with:

{"For US Claims:" if jurisdiction == "US" else "For UK Claims:"}
{"""
- HIPAA privacy requirements
- State insurance regulations
- ERISA requirements (if applicable)
- ADA compliance
- GLBA financial privacy
""" if jurisdiction == "US" else """
- FCA regulations
- GDPR data protection
- ICO privacy guidelines
- Solvency II requirements
- Financial Ombudsman guidelines
"""}

Check for:
1. Required documentation completeness
2. Proper authorization and consent
3. Data privacy compliance
4. Timely filing requirements
5. Benefit plan adherence
6. Missing compliance elements

Respond in JSON format with compliance_status, missing_requirements array, and violations array."""

        try:
            response = self.client.messages.create(
                model=settings.ANTHROPIC_MODEL,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            result = json.loads(response.content[0].text)
            logger.info("compliance_check_completed", status=result.get('compliance_status'))
            return result
            
        except Exception as e:
            logger.error("compliance_check_failed", error=str(e))
            return {
                "error": str(e),
                "compliance_status": "NEEDS_REVIEW",
                "requires_manual_review": True
            }


class FinancialAnalystAgent(ClaimAgent):
    """Agent specialized in financial validation and benefit calculation"""
    
    def __init__(self):
        super().__init__("FinancialAnalyst", "Financial Validation")
        
    async def process(self, claim_data: Dict[str, Any], context: str) -> Dict[str, Any]:
        """Analyze financial aspects of the claim"""
        
        prompt = f"""You are a financial analyst validating insurance claim amounts and benefit calculations.

Financial Information:
{json.dumps(claim_data.get('financialInformation', {}), indent=2, default=str)}

Medical Information:
{json.dumps(claim_data.get('medicalInformation', {}), indent=2, default=str)}

Policy Information:
- Policy Number: {claim_data.get('policyHolder', {}).get('policyNumber')}
- Claim Type: {claim_data.get('claimType')}

Analyze:
1. Claimed amount reasonableness
2. Itemized bill validation
3. Procedure code matching with charges
4. Standard pricing comparison
5. Benefit calculation
6. Deductible and co-insurance application
7. Out-of-network considerations
8. Coordination of benefits (if other insurance exists)

Calculate:
- Total claimed: $X
- Eligible amount: $Y
- Patient responsibility: $Z
- Insurer payment: $W

Respond in JSON format with calculated_benefit, adjustments array, and validation_status."""

        try:
            response = self.client.messages.create(
                model=settings.ANTHROPIC_MODEL,
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            result = json.loads(response.content[0].text)
            logger.info("financial_analysis_completed", calculated_benefit=result.get('calculated_benefit'))
            return result
            
        except Exception as e:
            logger.error("financial_analysis_failed", error=str(e))
            return {
                "error": str(e),
                "validation_status": "NEEDS_REVIEW",
                "requires_manual_calculation": True
            }


class ClaimOrchestrator:
    """Orchestrates multiple AI agents for comprehensive claim processing"""
    
    def __init__(self):
        self.medical_agent = MedicalReviewAgent()
        self.fraud_agent = FraudDetectionAgent()
        self.compliance_agent = ComplianceAgent()
        self.financial_agent = FinancialAnalystAgent()
        self.logger = structlog.get_logger(__name__)
        
    async def process_claim(
        self, 
        claim_request: TextBasedClaimRequest
    ) -> Dict[str, Any]:
        """
        Orchestrate multi-agent claim processing
        Returns comprehensive analysis and decision
        """
        
        claim_data = claim_request.dict()
        claim_id = str(claim_request.submissionMetadata.correlationId)
        
        self.logger.info(
            "claim_processing_started",
            claim_id=claim_id,
            claim_type=claim_request.claimType,
            jurisdiction=claim_request.jurisdiction
        )
        
        # Context for all agents
        context = f"""
        Claim ID: {claim_id}
        Submission Time: {claim_request.submissionMetadata.submissionTimestamp}
        Channel: {claim_request.submissionMetadata.channel}
        """
        
        # Run agents in parallel (in production, use asyncio.gather)
        results = {}
        
        try:
            # Medical Review
            if claim_request.medicalInformation:
                results['medical_review'] = await self.medical_agent.process(claim_data, context)
            
            # Fraud Detection
            results['fraud_detection'] = await self.fraud_agent.process(claim_data, context)
            
            # Compliance Check
            results['compliance'] = await self.compliance_agent.process(claim_data, context)
            
            # Financial Analysis
            if claim_request.financialInformation:
                results['financial_analysis'] = await self.financial_agent.process(claim_data, context)
            
            # Aggregate results and make decision
            decision = self._make_decision(results)
            
            self.logger.info(
                "claim_processing_completed",
                claim_id=claim_id,
                decision=decision['status'],
                confidence=decision['confidence']
            )
            
            return decision
            
        except Exception as e:
            self.logger.error("claim_processing_failed", claim_id=claim_id, error=str(e))
            return {
                'status': ClaimStatus.UNDER_REVIEW,
                'automation_level': 'MANUAL_REVIEW',
                'confidence': 0.0,
                'error': str(e),
                'requires_human_review': True
            }
    
    def _make_decision(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Aggregate agent results and make final decision"""
        
        # Extract key metrics
        medical_confidence = results.get('medical_review', {}).get('confidence_score', 0)
        fraud_risk = results.get('fraud_detection', {}).get('risk_score', 100)
        compliance_ok = results.get('compliance', {}).get('compliance_status') == 'COMPLIANT'
        
        # Decision logic
        overall_confidence = medical_confidence * (1 - fraud_risk / 100)
        
        if fraud_risk > settings.FRAUD_DETECTION_THRESHOLD * 100:
            status = ClaimStatus.UNDER_REVIEW
            automation_level = "MANUAL_REVIEW"
            agent_assigned = "fraud_investigation_team"
            
        elif not compliance_ok:
            status = ClaimStatus.ADDITIONAL_INFO_REQUIRED
            automation_level = "HYBRID"
            agent_assigned = "compliance_team"
            
        elif overall_confidence >= settings.AUTO_APPROVE_THRESHOLD:
            status = ClaimStatus.APPROVED
            automation_level = "FULLY_AUTOMATED"
            agent_assigned = "automated_claims_processor"
            
        else:
            status = ClaimStatus.PROCESSING
            automation_level = "HYBRID"
            agent_assigned = "claims_adjuster"
        
        return {
            'status': status,
            'automation_level': automation_level,
            'agent_assigned': agent_assigned,
            'confidence': overall_confidence,
            'agent_results': results,
            'processing_timestamp': datetime.utcnow().isoformat()
        }
