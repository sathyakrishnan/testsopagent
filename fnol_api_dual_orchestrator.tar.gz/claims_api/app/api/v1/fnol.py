"""
FNOL Claims API Endpoints
First Notice of Loss capture with AI-powered estimation
"""
from fastapi import APIRouter, Depends, HTTPException, status
from typing import Optional
import structlog
from uuid import uuid4
from datetime import datetime

from app.models.fnol_schemas import (
    FNOLClaimRequest,
    FNOLSubmissionResponse,
    ClaimEstimationResponse,
    DataEnrichmentResponse
)
from app.core.security import get_current_user, require_scope
from app.services.claim_estimation_service import ClaimEstimationService
from app.core.rate_limiter import limiter
from app.core.config import settings

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post(
    "/fnol",
    response_model=FNOLSubmissionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submit FNOL with Dual AI Estimation",
    description="Submit First Notice of Loss and receive AI-powered claim estimation from GPT-4o and Claude"
)
@limiter.limit(f"{settings.RATE_LIMIT_TEXT_CLAIMS}/minute")
async def submit_fnol_with_estimation(
    fnol_request: FNOLClaimRequest,
    ai_provider: str = "both",  # Options: "gpt4o", "claude", "both"
    include_data_recommendations: bool = False,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:write"))
):
    """
    Submit FNOL and receive comprehensive claim estimation
    
    **AI Provider Options:**
    - `both` (default): Uses both GPT-4o and Claude, orchestrates results for best accuracy
    - `gpt4o`: Uses only GPT-4o for estimation
    - `claude`: Uses only Claude Sonnet 4 for estimation
    
    **Process Flow:**
    1. Validate FNOL data
    2. Generate claim ID and number
    3. Use AI (GPT-4o + Claude) to estimate claim costs
    4. Assess severity and risk factors
    5. Provide next steps and recommendations
    6. Optionally suggest additional data to collect
    
    **Response includes:**
    - Estimated total cost with range
    - Cost breakdown (medical, property, wages)
    - Severity assessment
    - Confidence score
    - Risk factors and red flags
    - Recommended next steps
    - Settlement timeline estimate
    - AI orchestration metadata (when using "both")
    """
    
    logger.info(
        "fnol_submission_received",
        claim_type=fnol_request.claimType,
        jurisdiction=fnol_request.jurisdiction,
        incident_type=fnol_request.incidentDetails.incidentType,
        submitter=current_user.get("sub"),
        urgency=fnol_request.submissionMetadata.urgencyLevel,
        ai_provider=ai_provider
    )
    
    try:
        # Validate policy
        # await validate_policy(fnol_request.policyHolder.policyNumber)
        
        # Generate claim identifiers
        claim_id = uuid4()
        claim_number = _generate_claim_number(
            fnol_request.jurisdiction,
            fnol_request.locale.state if fnol_request.locale else None,
            claim_id
        )
        
        # Initialize estimation service
        estimation_service = ClaimEstimationService()
        
        # Validate ai_provider parameter
        if ai_provider not in ["gpt4o", "claude", "both"]:
            ai_provider = "both"  # Default to both
        
        # Get AI-powered estimation
        estimation_result = await estimation_service.estimate_claim(
            fnol_request,
            ai_provider=ai_provider
        )
        
        # Convert to response model
        estimation_response = ClaimEstimationResponse(**estimation_result)
        
        # Assess data completeness
        data_completeness = _assess_data_completeness(fnol_request)
        
        # Determine next steps based on estimation and completeness
        next_steps = _determine_next_steps(
            estimation_response,
            data_completeness,
            fnol_request
        )
        
        # Store FNOL and estimation in database
        # await store_fnol_claim(claim_id, fnol_request, estimation_response)
        
        # Build response
        response = FNOLSubmissionResponse(
            claimId=claim_id,
            claimNumber=claim_number,
            status="RECEIVED",
            submissionTimestamp=datetime.utcnow(),
            fnolData=fnol_request.dict(),
            estimation=estimation_response,
            dataCompleteness=data_completeness,
            nextSteps=next_steps,
            estimatedProcessingTime=_calculate_processing_time(estimation_response)
        )
        
        # Get data enrichment recommendations if requested
        if include_data_recommendations:
            enrichment = await estimation_service.enrich_claim_data(
                fnol_request,
                estimation_result
            )
            response.dataEnrichmentRecommendations = enrichment
        
        logger.info(
            "fnol_processed_successfully",
            claim_id=str(claim_id),
            claim_number=claim_number,
            estimated_cost=estimation_response.estimated_total_cost.amount,
            severity=estimation_response.severity_assessment,
            confidence=estimation_response.confidence_score
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("fnol_processing_failed", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process FNOL. Please try again."
        )


@router.post(
    "/fnol/estimate-only",
    response_model=ClaimEstimationResponse,
    status_code=status.HTTP_200_OK,
    summary="Get Claim Estimation Only",
    description="Get AI-powered claim estimation without submitting FNOL (GPT-4o + Claude orchestration)"
)
@limiter.limit(f"{settings.RATE_LIMIT_TEXT_CLAIMS}/minute")
async def get_claim_estimation(
    fnol_data: FNOLClaimRequest,
    ai_provider: str = "both",  # Options: "gpt4o", "claude", "both"
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:read"))
):
    """
    Get claim cost estimation without submitting claim
    
    **AI Provider Options:**
    - `both` (default): Orchestrated results from GPT-4o and Claude
    - `gpt4o`: GPT-4o only
    - `claude`: Claude Sonnet 4 only
    
    Useful for:
    - Pre-submission cost estimates
    - "What-if" scenarios
    - Training and education
    - Historical analysis
    """
    
    logger.info(
        "estimation_only_request",
        claim_type=fnol_data.claimType,
        jurisdiction=fnol_data.jurisdiction,
        requester=current_user.get("sub"),
        ai_provider=ai_provider
    )
    
    try:
        # Validate ai_provider
        if ai_provider not in ["gpt4o", "claude", "both"]:
            ai_provider = "both"
        
        estimation_service = ClaimEstimationService()
        estimation_result = await estimation_service.estimate_claim(
            fnol_data,
            ai_provider=ai_provider
        )
        
        return ClaimEstimationResponse(**estimation_result)
        
    except Exception as e:
        logger.error("estimation_failed", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate estimation"
        )


@router.post(
    "/fnol/{claim_id}/enrich",
    response_model=DataEnrichmentResponse,
    status_code=status.HTTP_200_OK,
    summary="Get Data Collection Recommendations",
    description="Get AI-powered recommendations for additional data to collect"
)
async def get_data_enrichment_recommendations(
    claim_id: str,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:read"))
):
    """
    Get recommendations for additional data to collect
    
    Returns:
    - Critical missing data points
    - Recommended documentation
    - Suggested follow-up questions
    - Priority level
    """
    
    try:
        # Retrieve claim from database
        # fnol_data, estimation = await get_claim_data(claim_id)
        
        # For demo, return structured recommendations
        return DataEnrichmentResponse(
            critical_missing_data=[
                "Detailed medical diagnosis from treating physician",
                "Police report with accident details",
                "Vehicle damage assessment photos"
            ],
            recommended_documentation=[
                "Hospital admission records",
                "Ambulance transport report",
                "Witness statements"
            ],
            suggested_questions=[
                "Was the airbag deployed?",
                "Were there any pre-existing injuries?",
                "Has claimant sought legal representation?"
            ],
            specialist_review_needed=False,
            priority_level="MEDIUM"
        )
        
    except Exception as e:
        logger.error("enrichment_failed", claim_id=claim_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Claim not found"
        )


@router.get(
    "/fnol/{claim_id}",
    response_model=FNOLSubmissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Get FNOL Claim Details",
    description="Retrieve FNOL claim with estimation"
)
async def get_fnol_claim(
    claim_id: str,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:read"))
):
    """Get complete FNOL claim details including estimation"""
    
    logger.info(
        "fnol_retrieval_requested",
        claim_id=claim_id,
        requester=current_user.get("sub")
    )
    
    try:
        # Retrieve from database
        # claim_data = await get_fnol_by_id(claim_id)
        
        # Mock response for demonstration
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Claim not found"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("fnol_retrieval_failed", claim_id=claim_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve claim"
        )


@router.put(
    "/fnol/{claim_id}/update",
    response_model=FNOLSubmissionResponse,
    status_code=status.HTTP_200_OK,
    summary="Update FNOL with Additional Data",
    description="Add additional information to existing FNOL and re-estimate"
)
async def update_fnol_claim(
    claim_id: str,
    updated_data: FNOLClaimRequest,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:write"))
):
    """
    Update FNOL with additional data and re-run estimation
    
    Use this endpoint when:
    - Additional details become available
    - Initial estimate needs refinement
    - Corrections are needed
    """
    
    logger.info(
        "fnol_update_requested",
        claim_id=claim_id,
        updater=current_user.get("sub")
    )
    
    try:
        # Verify claim exists
        # existing_claim = await get_fnol_by_id(claim_id)
        
        # Re-run estimation with updated data
        estimation_service = ClaimEstimationService()
        new_estimation = await estimation_service.estimate_claim(updated_data)
        
        # Update database
        # await update_fnol_claim_data(claim_id, updated_data, new_estimation)
        
        logger.info(
            "fnol_updated_successfully",
            claim_id=claim_id,
            new_estimate=new_estimation.get('estimated_total_cost')
        )
        
        # Return updated claim (mock for now)
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Update functionality coming soon"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("fnol_update_failed", claim_id=claim_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update claim"
        )


# Helper Functions
def _generate_claim_number(
    jurisdiction: str,
    state: Optional[str],
    claim_id: uuid4
) -> str:
    """Generate human-readable claim number"""
    from datetime import datetime
    
    year = datetime.utcnow().year
    state_code = state[:2].upper() if state else "XX"
    short_id = str(claim_id)[:8].upper()
    
    return f"FNOL-{year}-{jurisdiction}-{state_code}-{short_id}"


def _assess_data_completeness(fnol_request: FNOLClaimRequest) -> dict:
    """Assess completeness of FNOL data"""
    
    completeness = {
        "overall_score": 0.0,
        "categories": {}
    }
    
    # Check each category
    categories = {
        "policyHolder": _check_policyholder_completeness(fnol_request.policyHolder),
        "incidentDetails": _check_incident_completeness(fnol_request.incidentDetails),
        "immediateActions": _check_actions_completeness(fnol_request.immediateActions),
        "thirdPartyInfo": _check_third_party_completeness(fnol_request.thirdPartyInformation),
        "consents": _check_consents_completeness(fnol_request.consentAndAuthorizations)
    }
    
    completeness["categories"] = categories
    completeness["overall_score"] = sum(categories.values()) / len(categories)
    
    return completeness


def _check_policyholder_completeness(holder) -> float:
    """Check policyholder data completeness (0-1)"""
    fields = 0
    total = 5
    
    if holder.policyNumber:
        fields += 1
    if holder.firstName and holder.lastName:
        fields += 1
    if holder.dateOfBirth:
        fields += 1
    if holder.contactInformation and holder.contactInformation.primaryPhone:
        fields += 1
    if holder.contactInformation and holder.contactInformation.email:
        fields += 1
    
    return fields / total


def _check_incident_completeness(incident) -> float:
    """Check incident data completeness (0-1)"""
    fields = 0
    total = 6
    
    if incident.incidentDate:
        fields += 1
    if incident.incidentType:
        fields += 1
    if incident.incidentDescription and len(incident.incidentDescription) > 20:
        fields += 1
    if incident.incidentLocation:
        fields += 1
    if incident.injuriesReported:
        fields += 1
    if incident.emergencyServicesInvolved:
        fields += 1
    
    return fields / total


def _check_actions_completeness(actions) -> float:
    """Check immediate actions completeness (0-1)"""
    if not actions:
        return 0.3  # Minimum for having basic FNOL
    
    fields = 0
    total = 3
    
    if actions.currentMedicalCare:
        fields += 1
    if actions.ableToWork is not None:
        fields += 1
    if actions.vehicleDetails:
        fields += 1
    
    return fields / total


def _check_third_party_completeness(third_party) -> float:
    """Check third party info completeness (0-1)"""
    if not third_party or not third_party.thirdPartyInvolved:
        return 1.0  # Not applicable
    
    if not third_party.thirdPartyDetails:
        return 0.2
    
    fields = 0
    total = 3
    details = third_party.thirdPartyDetails
    
    if details.name:
        fields += 1
    if details.contactPhone:
        fields += 1
    if details.insuranceCompany:
        fields += 1
    
    return fields / total


def _check_consents_completeness(consents) -> float:
    """Check consents completeness (0-1)"""
    if not consents:
        return 0.0
    
    fields = 0
    total = 3
    
    if consents.medicalRecordsRelease:
        fields += 1
    if consents.dataProcessingConsent:
        fields += 1
    if consents.thirdPartyContactAuthorization:
        fields += 1
    
    return fields / total


def _determine_next_steps(
    estimation: ClaimEstimationResponse,
    completeness: dict,
    fnol_data: FNOLClaimRequest
) -> list:
    """Determine next steps based on estimation and data completeness"""
    
    steps = []
    
    # Severity-based steps
    if estimation.severity_assessment in ["SEVERE", "CATASTROPHIC"]:
        steps.append("Assign senior adjuster for review")
        steps.append("Schedule field inspection within 24 hours")
    
    # Completeness-based steps
    if completeness["overall_score"] < 0.7:
        steps.append("Request additional documentation from claimant")
    
    # Medical care steps
    if (fnol_data.immediateActions and 
        fnol_data.immediateActions.currentMedicalCare and
        fnol_data.immediateActions.currentMedicalCare.admittedToHospital):
        steps.append("Request hospital admission records")
        steps.append("Contact treating physician for medical report")
    
    # Third party steps
    if (fnol_data.thirdPartyInformation and 
        fnol_data.thirdPartyInformation.thirdPartyInvolved):
        steps.append("Contact third party insurer for liability determination")
    
    # Work-related steps
    if fnol_data.incidentDetails.workRelated:
        steps.append("Coordinate with workers' compensation carrier")
    
    # Add AI-recommended steps
    if estimation.next_steps:
        steps.extend(estimation.next_steps[:3])  # Top 3 AI recommendations
    
    return list(set(steps))  # Remove duplicates


def _calculate_processing_time(estimation: ClaimEstimationResponse) -> str:
    """Calculate estimated processing time based on severity and complexity"""
    
    severity = estimation.severity_assessment
    confidence = estimation.confidence_score
    
    if severity == "CATASTROPHIC":
        return "10-15 business days"
    elif severity == "SEVERE":
        return "7-10 business days"
    elif severity == "MODERATE" and confidence < 0.7:
        return "5-7 business days"
    else:
        return "3-5 business days"
