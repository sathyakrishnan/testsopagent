"""
FNOL Claims Estimation Service
Uses dual AI orchestrator: GPT-4o + Claude for intelligent claim estimation
"""
from typing import Dict, Any, List, Optional, Literal
from openai import AsyncOpenAI
from anthropic import AsyncAnthropic
import structlog
from datetime import datetime
import json

from app.core.config import settings
from app.models.fnol_schemas import FNOLClaimRequest

logger = structlog.get_logger(__name__)


class ClaimEstimationService:
    """Intelligent claim estimation using dual AI orchestrator (GPT-4o + Claude)"""
    
    def __init__(self):
        # Initialize both AI providers
        self.openai_client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.anthropic_client = AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        
        # Model configurations
        self.openai_model = "gpt-4o"  # GPT-4 Omni for comprehensive analysis
        self.claude_model = "claude-sonnet-4-20250514"  # Claude Sonnet 4 for validation
        
    async def estimate_claim(
        self, 
        fnol_data: FNOLClaimRequest,
        ai_provider: Literal["gpt4o", "claude", "both"] = "both"
    ) -> Dict[str, Any]:
        """
        Generate comprehensive claim estimate using dual AI orchestrator
        
        Args:
            fnol_data: FNOL claim request data
            ai_provider: Which AI to use ("gpt4o", "claude", or "both")
            
        Returns:
            Estimated costs, severity, processing recommendations
        """
        
        logger.info(
            "claim_estimation_started",
            claim_type=fnol_data.claimType,
            jurisdiction=fnol_data.jurisdiction,
            incident_type=fnol_data.incidentDetails.incidentType,
            ai_provider=ai_provider
        )
        
        try:
            if ai_provider == "both":
                # Use dual orchestrator for best results
                gpt4o_result = await self._estimate_with_gpt4o(fnol_data)
                claude_result = await self._estimate_with_claude(fnol_data)
                
                # Combine and validate results
                estimation = self._orchestrate_results(gpt4o_result, claude_result, fnol_data)
                
            elif ai_provider == "gpt4o":
                estimation = await self._estimate_with_gpt4o(fnol_data)
                
            elif ai_provider == "claude":
                estimation = await self._estimate_with_claude(fnol_data)
                
            else:
                raise ValueError(f"Invalid ai_provider: {ai_provider}")
            
            logger.info(
                "claim_estimation_completed",
                estimated_amount=estimation.get('estimated_total_cost'),
                severity=estimation.get('severity_assessment'),
                confidence=estimation.get('confidence_score'),
                ai_provider=ai_provider
            )
            
            return estimation
            
        except Exception as e:
            logger.error("claim_estimation_failed", error=str(e), exc_info=True)
            return self._fallback_estimation(fnol_data)
    
    async def _estimate_with_gpt4o(self, fnol_data: FNOLClaimRequest) -> Dict[str, Any]:
        """Generate estimation using GPT-4o"""
        
        estimation_prompt = self._build_estimation_prompt(fnol_data)
        
        response = await self.openai_client.chat.completions.create(
            model=self.openai_model,
            messages=[
                {
                    "role": "system",
                    "content": self._get_system_prompt(fnol_data.jurisdiction)
                },
                {
                    "role": "user",
                    "content": estimation_prompt
                }
            ],
            temperature=0.3,
            max_tokens=2000,
            response_format={"type": "json_object"}
        )
        
        estimation = json.loads(response.choices[0].message.content)
        
        # Add metadata
        estimation['meta'] = {
            'model': 'gpt-4o',
            'timestamp': datetime.utcnow().isoformat(),
            'prompt_tokens': response.usage.prompt_tokens,
            'completion_tokens': response.usage.completion_tokens,
            'total_tokens': response.usage.total_tokens
        }
        
        return estimation
    
    async def _estimate_with_claude(self, fnol_data: FNOLClaimRequest) -> Dict[str, Any]:
        """Generate estimation using Claude Sonnet 4"""
        
        estimation_prompt = self._build_estimation_prompt(fnol_data)
        
        response = await self.anthropic_client.messages.create(
            model=self.claude_model,
            max_tokens=2000,
            temperature=0.3,
            system=self._get_system_prompt(fnol_data.jurisdiction),
            messages=[
                {
                    "role": "user",
                    "content": estimation_prompt
                }
            ]
        )
        
        # Extract JSON from Claude's response
        content = response.content[0].text
        
        # Claude might wrap JSON in markdown, extract it
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()
        
        estimation = json.loads(content)
        
        # Add metadata
        estimation['meta'] = {
            'model': 'claude-sonnet-4',
            'timestamp': datetime.utcnow().isoformat(),
            'input_tokens': response.usage.input_tokens,
            'output_tokens': response.usage.output_tokens
        }
        
        return estimation
    
    def _orchestrate_results(
        self, 
        gpt4o_result: Dict[str, Any], 
        claude_result: Dict[str, Any],
        fnol_data: FNOLClaimRequest
    ) -> Dict[str, Any]:
        """
        Orchestrate results from both AI models
        Uses weighted averaging and consensus logic
        """
        
        logger.info("orchestrating_dual_ai_results")
        
        # Average the cost estimates
        gpt4o_amount = gpt4o_result.get('estimated_total_cost', {}).get('amount', 0)
        claude_amount = claude_result.get('estimated_total_cost', {}).get('amount', 0)
        
        # Weight by confidence scores
        gpt4o_confidence = gpt4o_result.get('confidence_score', 0.5)
        claude_confidence = claude_result.get('confidence_score', 0.5)
        
        # Weighted average
        total_weight = gpt4o_confidence + claude_confidence
        if total_weight > 0:
            final_amount = (
                (gpt4o_amount * gpt4o_confidence + claude_amount * claude_confidence) 
                / total_weight
            )
        else:
            final_amount = (gpt4o_amount + claude_amount) / 2
        
        # Calculate range from both estimates
        min_amount = min(
            gpt4o_result.get('estimated_total_cost', {}).get('range', {}).get('min', final_amount * 0.7),
            claude_result.get('estimated_total_cost', {}).get('range', {}).get('min', final_amount * 0.7)
        )
        max_amount = max(
            gpt4o_result.get('estimated_total_cost', {}).get('range', {}).get('max', final_amount * 1.5),
            claude_result.get('estimated_total_cost', {}).get('range', {}).get('max', final_amount * 1.5)
        )
        
        # Severity assessment - use more conservative (higher) assessment
        severity_order = ["MINOR", "MODERATE", "SEVERE", "CATASTROPHIC"]
        gpt4o_severity = gpt4o_result.get('severity_assessment', 'MODERATE')
        claude_severity = claude_result.get('severity_assessment', 'MODERATE')
        
        gpt4o_idx = severity_order.index(gpt4o_severity) if gpt4o_severity in severity_order else 1
        claude_idx = severity_order.index(claude_severity) if claude_severity in severity_order else 1
        final_severity = severity_order[max(gpt4o_idx, claude_idx)]
        
        # Combine risk factors from both
        risk_factors = list(set(
            gpt4o_result.get('risk_factors', []) + 
            claude_result.get('risk_factors', [])
        ))
        
        # Combine red flags
        red_flags = list(set(
            gpt4o_result.get('red_flags', []) + 
            claude_result.get('red_flags', [])
        ))
        
        # Combine next steps
        next_steps = list(set(
            gpt4o_result.get('next_steps', []) + 
            claude_result.get('next_steps', [])
        ))[:10]  # Top 10
        
        # Cost breakdown - average both
        gpt4o_breakdown = gpt4o_result.get('cost_breakdown', {})
        claude_breakdown = claude_result.get('cost_breakdown', {})
        
        cost_breakdown = {
            'medical_expenses': (
                gpt4o_breakdown.get('medical_expenses', 0) + 
                claude_breakdown.get('medical_expenses', 0)
            ) / 2,
            'property_damage': (
                gpt4o_breakdown.get('property_damage', 0) + 
                claude_breakdown.get('property_damage', 0)
            ) / 2,
            'lost_wages': (
                gpt4o_breakdown.get('lost_wages', 0) + 
                claude_breakdown.get('lost_wages', 0)
            ) / 2,
            'other_costs': (
                gpt4o_breakdown.get('other_costs', 0) + 
                claude_breakdown.get('other_costs', 0)
            ) / 2
        }
        
        # Use Claude's analysis for text, GPT-4o for similar claims
        similar_claims = gpt4o_result.get('similar_claims_analysis', claude_result.get('similar_claims_analysis', ''))
        special_considerations = claude_result.get('special_considerations', gpt4o_result.get('special_considerations', []))
        
        # Combined confidence - average of both
        final_confidence = (gpt4o_confidence + claude_confidence) / 2
        
        # Build orchestrated result
        orchestrated = {
            'estimated_total_cost': {
                'amount': round(final_amount, 2),
                'currency': gpt4o_result.get('estimated_total_cost', {}).get('currency', 'USD'),
                'range': {
                    'min': round(min_amount, 2),
                    'max': round(max_amount, 2)
                }
            },
            'cost_breakdown': {
                k: round(v, 2) for k, v in cost_breakdown.items()
            },
            'severity_assessment': final_severity,
            'confidence_score': round(final_confidence, 2),
            'estimated_settlement_time': gpt4o_result.get(
                'estimated_settlement_time', 
                claude_result.get('estimated_settlement_time', '30-60 days')
            ),
            'recommended_reserve': {
                'amount': round(final_amount * 1.2, 2),  # 20% buffer
                'justification': 'Orchestrated estimate from dual AI analysis with 20% reserve buffer'
            },
            'risk_factors': risk_factors,
            'red_flags': red_flags if red_flags else ['None identified'],
            'next_steps': next_steps,
            'similar_claims_analysis': similar_claims,
            'special_considerations': special_considerations,
            'meta': {
                'orchestration_method': 'dual_ai_weighted_average',
                'gpt4o_estimate': gpt4o_amount,
                'claude_estimate': claude_amount,
                'gpt4o_confidence': gpt4o_confidence,
                'claude_confidence': claude_confidence,
                'gpt4o_severity': gpt4o_severity,
                'claude_severity': claude_severity,
                'timestamp': datetime.utcnow().isoformat(),
                'models_used': ['gpt-4o', 'claude-sonnet-4']
            }
        }
        
        logger.info(
            "orchestration_completed",
            final_amount=final_amount,
            gpt4o_amount=gpt4o_amount,
            claude_amount=claude_amount,
            final_confidence=final_confidence
        )
        
        return orchestrated
    
    def _get_system_prompt(self, jurisdiction: str) -> str:
        """Get jurisdiction-specific system prompt"""
        
        base_prompt = """You are an expert insurance claims adjuster with 20+ years of experience 
in evaluating First Notice of Loss (FNOL) claims. Your role is to provide accurate, data-driven 
claim cost estimates based on initial incident information.

You must respond ONLY with valid JSON in the following structure:
{
  "estimated_total_cost": {
    "amount": <number>,
    "currency": "<USD or GBP>",
    "range": {"min": <number>, "max": <number>}
  },
  "cost_breakdown": {
    "medical_expenses": <number>,
    "property_damage": <number>,
    "lost_wages": <number>,
    "other_costs": <number>
  },
  "severity_assessment": "<MINOR|MODERATE|SEVERE|CATASTROPHIC>",
  "confidence_score": <0-1>,
  "estimated_settlement_time": "<timeframe>",
  "recommended_reserve": {
    "amount": <number>,
    "justification": "<string>"
  },
  "risk_factors": ["<array of strings>"],
  "red_flags": ["<array of strings>"],
  "next_steps": ["<array of strings>"],
  "similar_claims_analysis": "<string>",
  "special_considerations": ["<array of strings>"]
}"""

        jurisdiction_guidance = {
            "US": """
Consider US-specific factors:
- Average medical costs in the US (ER visit: $1,500-$3,000)
- Vehicle repair costs (average: $3,000-$10,000 for moderate damage)
- Lost wages calculation (average US income)
- Liability limits and tort system
- State-specific regulations
- Attorney involvement likelihood
- Workers' compensation if applicable""",
            
            "UK": """
Consider UK-specific factors:
- NHS coverage (most medical costs covered)
- Private medical treatment costs if applicable
- Vehicle repair costs in GBP
- UK compensation culture (typically lower than US)
- No-fault system considerations
- Solicitor involvement patterns
- UK personal injury tariffs"""
        }
        
        return base_prompt + "\n\n" + jurisdiction_guidance.get(jurisdiction, "")
    
    def _build_estimation_prompt(self, fnol_data: FNOLClaimRequest) -> str:
        """Build comprehensive estimation prompt from FNOL data"""
        
        prompt_parts = [
            "# FNOL Claim Estimation Request\n",
            f"**Claim Type:** {fnol_data.claimType}",
            f"**Jurisdiction:** {fnol_data.jurisdiction}",
            f"**Incident Type:** {fnol_data.incidentDetails.incidentType}\n",
            
            "## Incident Details",
            f"**Date/Time:** {fnol_data.incidentDetails.incidentDate}",
            f"**Location:** {self._format_location(fnol_data)}",
            f"**Description:** {fnol_data.incidentDetails.incidentDescription}\n"
        ]
        
        # Injury information
        if fnol_data.incidentDetails.injuriesReported:
            prompt_parts.append("## Reported Injuries")
            for injury in fnol_data.incidentDetails.injuriesReported:
                prompt_parts.append(f"- {injury}")
            prompt_parts.append("")
        
        # Medical care status
        if fnol_data.immediateActions and fnol_data.immediateActions.currentMedicalCare:
            care = fnol_data.immediateActions.currentMedicalCare
            prompt_parts.append("## Current Medical Status")
            prompt_parts.append(f"- Receiving treatment: {care.receivingTreatment}")
            if care.location:
                prompt_parts.append(f"- Location: {care.location}")
            if care.admittedToHospital is not None:
                prompt_parts.append(f"- Admitted to hospital: {care.admittedToHospital}")
            prompt_parts.append("")
        
        # Vehicle damage (if applicable)
        if (fnol_data.immediateActions and 
            fnol_data.immediateActions.vehicleDetails):
            vehicle = fnol_data.immediateActions.vehicleDetails
            prompt_parts.append("## Vehicle Damage")
            if vehicle.estimatedDamage:
                prompt_parts.append(f"- Damage level: {vehicle.estimatedDamage}")
            if vehicle.vehicleDriveable is not None:
                prompt_parts.append(f"- Vehicle driveable: {vehicle.vehicleDriveable}")
            prompt_parts.append("")
        
        # Emergency services
        if fnol_data.incidentDetails.emergencyServicesInvolved:
            services = fnol_data.incidentDetails.emergencyServicesInvolved
            prompt_parts.append("## Emergency Services")
            if services.policeNotified:
                prompt_parts.append(f"- Police notified: Yes")
                if services.policeReportNumber:
                    prompt_parts.append(f"- Report #: {services.policeReportNumber}")
            if services.ambulanceCalled:
                prompt_parts.append("- Ambulance called: Yes")
            prompt_parts.append("")
        
        # Third party involvement
        if (fnol_data.thirdPartyInformation and 
            fnol_data.thirdPartyInformation.thirdPartyInvolved):
            prompt_parts.append("## Third Party Involved")
            prompt_parts.append("- Yes, third party involved")
            if fnol_data.thirdPartyInformation.thirdPartyDetails:
                details = fnol_data.thirdPartyInformation.thirdPartyDetails
                if details.insuranceCompany:
                    prompt_parts.append(f"- Their insurance: {details.insuranceCompany}")
            prompt_parts.append("")
        
        # Work related
        if fnol_data.incidentDetails.workRelated:
            prompt_parts.append("## Additional Context")
            prompt_parts.append("- This is a work-related incident (Workers' Compensation may apply)")
            prompt_parts.append("")
        
        # Urgency level
        if fnol_data.submissionMetadata.urgencyLevel:
            prompt_parts.append(f"**Urgency Level:** {fnol_data.submissionMetadata.urgencyLevel}\n")
        
        prompt_parts.append("""
Based on this FNOL information, provide:
1. Estimated total claim cost with range (min-max)
2. Detailed cost breakdown by category
3. Severity assessment
4. Confidence score in your estimate (0-1)
5. Estimated time to settle
6. Recommended reserve amount
7. Key risk factors identified
8. Any red flags for potential fraud or complications
9. Recommended next steps for claim processing
10. Analysis of similar historical claims
11. Special considerations for this case

Remember to consider jurisdiction-specific factors and provide realistic estimates based on current market rates.
""")
        
        return "\n".join(prompt_parts)
    
    def _format_location(self, fnol_data: FNOLClaimRequest) -> str:
        """Format location information for prompt"""
        if not fnol_data.incidentDetails.incidentLocation:
            return "Location not specified"
        
        loc = fnol_data.incidentDetails.incidentLocation
        parts = []
        if loc.description:
            parts.append(loc.description)
        if loc.city:
            parts.append(loc.city)
        if loc.state:
            parts.append(loc.state)
        if loc.country:
            parts.append(loc.country)
        
        return ", ".join(parts) if parts else "Location not specified"
    
    def _fallback_estimation(self, fnol_data: FNOLClaimRequest) -> Dict[str, Any]:
        """Provide rule-based fallback estimate if GPT-4o fails"""
        
        # Simple rule-based estimation
        base_costs = {
            "US": {
                "MINOR": 5000,
                "MODERATE": 15000,
                "SEVERE": 50000,
                "TOTAL_LOSS": 100000
            },
            "UK": {
                "MINOR": 3000,
                "MODERATE": 10000,
                "SEVERE": 30000,
                "TOTAL_LOSS": 60000
            }
        }
        
        # Determine severity from available data
        severity = "MODERATE"  # Default
        if fnol_data.immediateActions and fnol_data.immediateActions.vehicleDetails:
            damage = fnol_data.immediateActions.vehicleDetails.estimatedDamage
            if damage == "MINOR":
                severity = "MINOR"
            elif damage == "SEVERE":
                severity = "SEVERE"
            elif damage == "TOTAL_LOSS":
                severity = "TOTAL_LOSS"
        
        currency = "USD" if fnol_data.jurisdiction == "US" else "GBP"
        base_amount = base_costs[fnol_data.jurisdiction][severity]
        
        return {
            "estimated_total_cost": {
                "amount": base_amount,
                "currency": currency,
                "range": {
                    "min": base_amount * 0.7,
                    "max": base_amount * 1.5
                }
            },
            "severity_assessment": severity,
            "confidence_score": 0.5,
            "estimated_settlement_time": "30-60 days",
            "next_steps": [
                "Request medical documentation",
                "Obtain vehicle damage assessment",
                "Verify policy coverage"
            ],
            "meta": {
                "estimation_method": "FALLBACK_RULE_BASED",
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    
    async def enrich_claim_data(
        self,
        fnol_data: FNOLClaimRequest,
        estimation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Use GPT-4o to suggest additional data to collect
        """
        
        prompt = f"""Based on this FNOL claim and initial estimation:

Claim Type: {fnol_data.claimType}
Severity: {estimation.get('severity_assessment')}
Estimated Cost: {estimation.get('estimated_total_cost', {}).get('amount')}

Current Information Available:
{json.dumps(fnol_data.dict(), indent=2, default=str)}

What additional information should we collect to improve claim accuracy?
Provide a prioritized list of missing data points that would significantly impact the estimate.

Respond in JSON format:
{{
  "critical_missing_data": ["<array>"],
  "recommended_documentation": ["<array>"],
  "suggested_questions": ["<array>"],
  "specialist_review_needed": "<boolean>",
  "priority_level": "<HIGH|MEDIUM|LOW>"
}}
"""
        
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a claims data analyst identifying missing information."
                    },
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1000,
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            logger.error("data_enrichment_failed", error=str(e))
            return {
                "critical_missing_data": [],
                "priority_level": "LOW"
            }
