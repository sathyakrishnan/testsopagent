#!/bin/bash
# Setup script for XYZ Claims Processing API

set -e

echo "🚀 XYZ Claims Processing API - Setup Script"
echo "============================================="

# Check prerequisites
echo ""
echo "📋 Checking prerequisites..."

command -v python3 >/dev/null 2>&1 || { echo "❌ Python 3 is required but not installed."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "⚠️  Docker not found. Skipping container setup."; SKIP_DOCKER=true; }
command -v docker-compose >/dev/null 2>&1 || { echo "⚠️  Docker Compose not found. Skipping container setup."; SKIP_DOCKER=true; }

echo "✅ Prerequisites check completed"

# Check Python version
PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "Python version: $PYTHON_VERSION"

if [ "$(echo "$PYTHON_VERSION < 3.11" | bc)" -eq 1 ]; then
    echo "⚠️  Python 3.11+ is recommended. You have $PYTHON_VERSION"
fi

# Setup mode selection
echo ""
echo "Select setup mode:"
echo "1. Docker (Recommended for quick start)"
echo "2. Local (Manual setup)"
echo "3. Azure (Cloud deployment)"
read -p "Enter choice [1-3]: " setup_mode

# Copy environment file
echo ""
echo "📝 Setting up environment configuration..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Created .env file from template"
    echo "⚠️  IMPORTANT: Edit .env and add your API keys!"
else
    echo "ℹ️  .env file already exists"
fi

# Docker setup
if [ "$setup_mode" = "1" ] && [ "$SKIP_DOCKER" != "true" ]; then
    echo ""
    echo "🐳 Starting Docker containers..."
    
    # Check if Anthropic key is set
    if [ -z "$ANTHROPIC_API_KEY" ]; then
        read -p "Enter your Anthropic API key: " ANTHROPIC_API_KEY
        export ANTHROPIC_API_KEY
    fi
    
    # Build and start containers
    docker-compose up -d --build
    
    echo ""
    echo "⏳ Waiting for services to be ready..."
    sleep 10
    
    # Check container status
    docker-compose ps
    
    echo ""
    echo "✅ Docker setup completed!"
    echo ""
    echo "📍 Services available at:"
    echo "   - API: http://localhost:8000"
    echo "   - API Docs: http://localhost:8000/api/docs"
    echo "   - Flower: http://localhost:5555"
    echo ""
    echo "🔧 Useful commands:"
    echo "   - View logs: docker-compose logs -f api"
    echo "   - Stop services: docker-compose down"
    echo "   - Restart: docker-compose restart"

# Local setup
elif [ "$setup_mode" = "2" ]; then
    echo ""
    echo "💻 Setting up local environment..."
    
    # Create virtual environment
    if [ ! -d "venv" ]; then
        echo "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    echo "Activating virtual environment..."
    source venv/bin/activate
    
    # Upgrade pip
    echo "Upgrading pip..."
    pip install --upgrade pip
    
    # Install dependencies
    echo "Installing dependencies..."
    pip install -r requirements.txt
    
    echo ""
    echo "✅ Local setup completed!"
    echo ""
    echo "⚠️  Before running the API, make sure you have:"
    echo "   - PostgreSQL running on localhost:5432"
    echo "   - Redis running on localhost:6379"
    echo "   - Updated .env with your credentials"
    echo ""
    echo "To start the API:"
    echo "   source venv/bin/activate"
    echo "   uvicorn app.main:app --reload"

# Azure setup
elif [ "$setup_mode" = "3" ]; then
    echo ""
    echo "☁️  Azure deployment setup..."
    
    # Check Azure CLI
    command -v az >/dev/null 2>&1 || { 
        echo "❌ Azure CLI is required for cloud deployment"
        echo "Install: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    }
    
    # Check login status
    az account show >/dev/null 2>&1 || { 
        echo "Please login to Azure first:"
        echo "  az login"
        exit 1
    }
    
    read -p "Enter resource group name: " RESOURCE_GROUP
    read -p "Enter environment (dev/staging/production): " ENVIRONMENT
    read -sp "Enter PostgreSQL password: " PG_PASSWORD
    echo ""
    
    # Create resource group if it doesn't exist
    echo "Creating resource group..."
    az group create --name "$RESOURCE_GROUP" --location eastus
    
    # Deploy infrastructure
    echo "Deploying Azure infrastructure..."
    az deployment group create \
        --resource-group "$RESOURCE_GROUP" \
        --template-file azure-deployment.bicep \
        --parameters environment="$ENVIRONMENT" postgreSQLPassword="$PG_PASSWORD"
    
    echo ""
    echo "✅ Azure infrastructure deployed!"
    echo ""
    echo "📍 Next steps:"
    echo "   1. Get the App Service URL from Azure Portal"
    echo "   2. Configure GitHub Actions or Azure DevOps for CI/CD"
    echo "   3. Update Key Vault with secrets"
    echo "   4. Deploy application code"
fi

# Post-setup tasks
echo ""
echo "📚 Additional setup tasks:"
echo ""
echo "1. Configure API keys in .env:"
echo "   - ANTHROPIC_API_KEY (required for AI agents)"
echo "   - AZURE_* credentials (required for OCR and storage)"
echo ""
echo "2. Review security settings:"
echo "   - Change SECRET_KEY to a strong random string"
echo "   - Update OAuth credentials"
echo "   - Configure CORS origins"
echo ""
echo "3. Test the API:"
echo "   - Run tests: pytest"
echo "   - Access docs: http://localhost:8000/api/docs"
echo "   - Try health check: curl http://localhost:8000/api/health"
echo ""
echo "4. For Mendix integration:"
echo "   - Share MENDIX_API_SCHEMA.json with Mendix team"
echo "   - Configure OAuth credentials"
echo "   - Set up webhook endpoint"

echo ""
echo "🎉 Setup complete! Check README.md for detailed documentation."
echo ""
