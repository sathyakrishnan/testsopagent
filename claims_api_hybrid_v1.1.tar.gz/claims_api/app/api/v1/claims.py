"""
Claims API Endpoints
Handles text-based and OCR-based claim submissions
"""
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from fastapi.responses import JSONResponse
from typing import Optional
import structlog
from uuid import uuid4
from datetime import datetime

from app.models.schemas import (
    TextBasedClaimRequest,
    ClaimResponse,
    OCRRequest,
    OCRResponse,
    ClaimStatus,
    AIProcessing,
    NextStep,
    ErrorDetail
)
from app.core.security import get_current_user, require_scope
from app.services.ocr_service import OCRService
from app.agents.orchestrator import ClaimOrchestrator
from app.core.rate_limiter import limiter
from app.core.config import settings

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post(
    "/text",
    response_model=ClaimResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submit text-based claim",
    description="Submit structured claim data collected from FNOL process"
)
@limiter.limit(f"{settings.RATE_LIMIT_TEXT_CLAIMS}/minute")
async def submit_text_claim(
    claim: TextBasedClaimRequest,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:write"))
):
    """
    Submit a structured insurance claim
    
    - **claimType**: Type of insurance claim
    - **jurisdiction**: US or UK regulatory zone
    - **policyHolder**: Complete policyholder information
    - **incidentDetails**: Information about the incident
    - **medicalInformation**: Medical details (if applicable)
    - **financialInformation**: Billing and payment details
    
    Returns claim ID, status, and processing timeline
    """
    
    logger.info(
        "text_claim_received",
        claim_type=claim.claimType,
        jurisdiction=claim.jurisdiction,
        policy_number=claim.policyHolder.policyNumber,
        submitter=current_user.get("sub")
    )
    
    try:
        # Validate policy exists and is active
        # await validate_policy(claim.policyHolder.policyNumber)
        
        # Check for duplicate submission
        # if await is_duplicate_claim(claim):
        #     raise HTTPException(
        #         status_code=status.HTTP_409_CONFLICT,
        #         detail="Duplicate claim submission detected"
        #     )
        
        # Process claim through AI orchestrator
        orchestrator = ClaimOrchestrator()
        processing_result = await orchestrator.process_claim(claim)
        
        # Generate claim number
        claim_id = uuid4()
        claim_number = _generate_claim_number(
            claim.jurisdiction,
            claim.locale.state,
            claim_id
        )
        
        # Store claim in database
        # await store_claim(claim_id, claim, processing_result)
        
        # Prepare response
        response = ClaimResponse(
            claimId=claim_id,
            claimNumber=claim_number,
            status=processing_result['status'],
            submissionTimestamp=datetime.utcnow(),
            estimatedProcessingTime=_calculate_processing_time(processing_result),
            aiProcessing=AIProcessing(
                agentAssigned=processing_result['agent_assigned'],
                automationLevel=processing_result['automation_level'],
                confidenceScore=processing_result['confidence']
            ),
            nextSteps=_generate_next_steps(processing_result)
        )
        
        # Send webhook to Mendix (if configured)
        if settings.MENDIX_WEBHOOK_URL:
            await _send_mendix_webhook(response)
        
        logger.info(
            "text_claim_processed",
            claim_id=str(claim_id),
            claim_number=claim_number,
            status=response.status,
            automation_level=response.aiProcessing.automationLevel
        )
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("text_claim_processing_failed", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process claim. Please try again."
        )


@router.post(
    "/ocr",
    response_model=OCRResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit OCR-based claim",
    description="Upload claim document for OCR extraction and processing"
)
@limiter.limit(f"{settings.RATE_LIMIT_OCR_CLAIMS}/minute")
async def submit_ocr_claim(
    file: UploadFile = File(..., description="Claim document (PDF, JPEG, PNG, TIFF)"),
    documentType: str = Form(..., description="Type of document being uploaded"),
    jurisdiction: str = Form(..., description="US or UK"),
    policyNumber: Optional[str] = Form(None, description="Policy number if known"),
    correlationId: Optional[str] = Form(None, description="Correlation ID for tracking"),
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:write"))
):
    """
    Submit a claim document for OCR processing
    
    - **file**: Document file (max 10MB)
    - **documentType**: Type of document (CLAIM_FORM, MEDICAL_BILL, etc.)
    - **jurisdiction**: US or UK
    - **policyNumber**: Optional policy number for pre-filling
    
    Returns OCR job ID and processing status
    """
    
    logger.info(
        "ocr_claim_received",
        filename=file.filename,
        content_type=file.content_type,
        document_type=documentType,
        jurisdiction=jurisdiction,
        submitter=current_user.get("sub")
    )
    
    try:
        # Validate file
        _validate_upload_file(file)
        
        # Read file content
        file_content = await file.read()
        
        # Generate job ID
        job_id = uuid4()
        
        # Initialize OCR service
        ocr_service = OCRService()
        
        # Upload to blob storage
        document_url = await ocr_service.upload_document(
            file_content,
            file.filename,
            str(job_id)
        )
        
        # Start OCR extraction (async)
        # In production, this would be a Celery task
        extraction_result = await ocr_service.extract_from_document(
            document_url,
            documentType,
            jurisdiction
        )
        
        # Generate claim preview
        claim_preview = await ocr_service.generate_claim_preview(
            extraction_result,
            documentType,
            jurisdiction
        )
        
        # Store OCR job
        # await store_ocr_job(job_id, extraction_result, claim_preview)
        
        response = OCRResponse(
            ocrJobId=job_id,
            status="COMPLETED",
            extractedData=extraction_result,
            suggestedClaimType=claim_preview.get("claimType"),
            claimPreview=claim_preview
        )
        
        logger.info(
            "ocr_processing_completed",
            job_id=str(job_id),
            confidence=extraction_result.get("confidence"),
            fields_extracted=len(extraction_result.get("fields", {}))
        )
        
        return response
        
    except Exception as e:
        logger.error("ocr_processing_failed", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"OCR processing failed: {str(e)}"
        )


@router.get(
    "/{claim_id}/status",
    response_model=ClaimResponse,
    summary="Get claim status",
    description="Retrieve current status and details of a claim"
)
@limiter.limit(f"{settings.RATE_LIMIT_STATUS}/minute")
async def get_claim_status(
    claim_id: str,
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:read"))
):
    """
    Get current status of a claim
    
    - **claim_id**: Unique claim identifier (UUID or claim number)
    
    Returns complete claim status and processing details
    """
    
    logger.info(
        "claim_status_requested",
        claim_id=claim_id,
        requester=current_user.get("sub")
    )
    
    try:
        # Retrieve claim from database
        # claim = await get_claim_by_id(claim_id)
        
        # Mock response for demonstration
        return ClaimResponse(
            claimId=uuid4(),
            claimNumber="CLM-2024-US-FL-001234",
            status=ClaimStatus.PROCESSING,
            submissionTimestamp=datetime.utcnow(),
            estimatedProcessingTime="2-3 business days",
            aiProcessing=AIProcessing(
                agentAssigned="claims_adjuster_ai",
                automationLevel="HYBRID",
                confidenceScore=0.87
            ),
            nextSteps=[
                NextStep(
                    action="Awaiting physician statement verification",
                    dueDate=None,
                    responsible="PHYSICIAN"
                )
            ]
        )
        
    except Exception as e:
        logger.error("claim_status_retrieval_failed", claim_id=claim_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Claim not found"
        )


@router.put(
    "/{claim_id}/documents",
    status_code=status.HTTP_200_OK,
    summary="Upload additional documents",
    description="Add supporting documents to an existing claim"
)
async def upload_additional_documents(
    claim_id: str,
    files: list[UploadFile] = File(...),
    current_user: dict = Depends(get_current_user),
    _: None = Depends(require_scope("claims:write"))
):
    """Upload additional supporting documents to a claim"""
    
    logger.info(
        "additional_documents_upload",
        claim_id=claim_id,
        file_count=len(files),
        submitter=current_user.get("sub")
    )
    
    try:
        uploaded_files = []
        
        for file in files:
            _validate_upload_file(file)
            
            file_content = await file.read()
            
            # Upload to storage
            ocr_service = OCRService()
            file_url = await ocr_service.upload_document(
                file_content,
                file.filename,
                claim_id
            )
            
            uploaded_files.append({
                "fileName": file.filename,
                "fileUrl": file_url,
                "uploadedAt": datetime.utcnow().isoformat()
            })
        
        # Update claim record
        # await add_documents_to_claim(claim_id, uploaded_files)
        
        return {
            "message": "Documents uploaded successfully",
            "files": uploaded_files
        }
        
    except Exception as e:
        logger.error("document_upload_failed", claim_id=claim_id, error=str(e))
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to upload documents"
        )


# Helper Functions
def _validate_upload_file(file: UploadFile):
    """Validate uploaded file"""
    
    # Check file extension
    file_ext = f".{file.filename.split('.')[-1].lower()}"
    if file_ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File type {file_ext} not allowed. Allowed types: {settings.ALLOWED_EXTENSIONS}"
        )
    
    # Check file size (this is approximate, full check happens on read)
    if file.size and file.size > settings.MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File size exceeds maximum allowed size of {settings.MAX_FILE_SIZE / 1024 / 1024}MB"
        )


def _generate_claim_number(jurisdiction: str, state: Optional[str], claim_id: uuid4) -> str:
    """Generate human-readable claim number"""
    from datetime import datetime
    
    year = datetime.utcnow().year
    state_code = state[:2].upper() if state else "XX"
    short_id = str(claim_id)[:8].upper()
    
    return f"CLM-{year}-{jurisdiction}-{state_code}-{short_id}"


def _calculate_processing_time(processing_result: dict) -> str:
    """Calculate estimated processing time based on automation level"""
    
    automation = processing_result.get('automation_level', 'MANUAL_REVIEW')
    
    if automation == 'FULLY_AUTOMATED':
        return "1-2 business days"
    elif automation == 'HYBRID':
        return "3-5 business days"
    else:
        return "5-10 business days"


def _generate_next_steps(processing_result: dict) -> list[NextStep]:
    """Generate next steps based on processing results"""
    
    next_steps = []
    status = processing_result.get('status')
    
    if status == ClaimStatus.ADDITIONAL_INFO_REQUIRED:
        # Check what's missing
        compliance = processing_result.get('agent_results', {}).get('compliance', {})
        missing = compliance.get('missing_requirements', [])
        
        for requirement in missing:
            next_steps.append(NextStep(
                action=f"Submit {requirement}",
                dueDate=None,
                responsible="CLAIMANT"
            ))
    
    elif status == ClaimStatus.UNDER_REVIEW:
        next_steps.append(NextStep(
            action="Claim under manual review by claims adjuster",
            dueDate=None,
            responsible="INSURER"
        ))
    
    return next_steps if next_steps else None


async def _send_mendix_webhook(response: ClaimResponse):
    """Send claim status update to Mendix webhook"""
    import httpx
    
    if not settings.MENDIX_WEBHOOK_URL:
        return
    
    try:
        async with httpx.AsyncClient() as client:
            await client.post(
                settings.MENDIX_WEBHOOK_URL,
                json=response.dict(),
                headers={
                    "X-API-Key": settings.MENDIX_API_KEY,
                    "Content-Type": "application/json"
                },
                timeout=10
            )
    except Exception as e:
        logger.error("mendix_webhook_failed", error=str(e))
        # Don't fail the main request if webhook fails
