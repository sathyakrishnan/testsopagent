"""
Authentication Endpoints
OAuth 2.0 token generation and refresh
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from datetime import timedelta
from pydantic import BaseModel
import structlog

from app.core.config import settings
from app.core.security import create_access_token, create_refresh_token

router = APIRouter()
logger = structlog.get_logger(__name__)


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class TokenRefresh(BaseModel):
    refresh_token: str


@router.post("/token", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    OAuth 2.0 token endpoint
    Exchange credentials for access token
    """
    
    # Validate credentials against database
    # In production, verify username/password or client credentials
    # user = await authenticate_user(form_data.username, form_data.password)
    
    # Mock validation for demo
    if form_data.username == "mendix_client" and form_data.password == "secret":
        user_data = {
            "sub": "mendix_service_account",
            "scopes": form_data.scopes or ["claims:read", "claims:write"],
            "client_id": "mendix_client"
        }
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Create tokens
    access_token = create_access_token(
        data=user_data,
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    
    refresh_token = create_refresh_token(data=user_data)
    
    logger.info(
        "token_issued",
        user_id=user_data["sub"],
        scopes=user_data["scopes"],
        client_id=user_data["client_id"]
    )
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )


@router.post("/refresh", response_model=Token)
async def refresh_access_token(token_data: TokenRefresh):
    """
    Refresh access token using refresh token
    """
    from jose import JWTError, jwt
    
    try:
        # Decode refresh token
        payload = jwt.decode(
            token_data.refresh_token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        
        if payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type"
            )
        
        # Create new access token
        user_data = {
            "sub": payload.get("sub"),
            "scopes": payload.get("scopes", []),
            "client_id": payload.get("client_id")
        }
        
        access_token = create_access_token(data=user_data)
        new_refresh_token = create_refresh_token(data=user_data)
        
        logger.info("token_refreshed", user_id=user_data["sub"])
        
        return Token(
            access_token=access_token,
            refresh_token=new_refresh_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        )
        
    except JWTError as e:
        logger.error("token_refresh_failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
