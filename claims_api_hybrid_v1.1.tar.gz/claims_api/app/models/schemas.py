"""
Data models for Claims Processing API
Comprehensive validation for US and UK insurance claims
"""
from typing import Optional, List, Dict, Any
from datetime import datetime, date
from enum import Enum
from pydantic import BaseModel, Field, validator, EmailStr, constr
from uuid import UUID, uuid4


# Enumerations
class ClaimType(str, Enum):
    ACCIDENT = "ACCIDENT"
    DISABILITY = "DISABILITY"
    WAIVER_OF_PREMIUM = "WAIVER_OF_PREMIUM"
    HOSPITAL_RIDER = "HOSPITAL_RIDER"
    ROUTINE_PREGNANCY = "ROUTINE_PREGNANCY"
    DEATH_CLAIM = "DEATH_CLAIM"
    ANNUITY_WITHDRAWAL = "ANNUITY_WITHDRAWAL"
    GROUP_LIFE = "GROUP_LIFE"
    PAYMENT_AUTHORIZATION = "PAYMENT_AUTHORIZATION"


class Jurisdiction(str, Enum):
    US = "US"
    UK = "UK"


class Gender(str, Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"
    OTHER = "OTHER"
    PREFER_NOT_TO_SAY = "PREFER_NOT_TO_SAY"


class IncidentType(str, Enum):
    ACCIDENT = "ACCIDENT"
    ILLNESS = "ILLNESS"
    PREGNANCY = "PREGNANCY"
    DEATH = "DEATH"
    DISABILITY = "DISABILITY"


class WorkStatus(str, Enum):
    FULL_TIME = "FULL_TIME"
    PART_TIME = "PART_TIME"
    LIGHT_DUTY = "LIGHT_DUTY"
    UNABLE = "UNABLE"


class DisabilityType(str, Enum):
    TEMPORARY_TOTAL = "TEMPORARY_TOTAL"
    TEMPORARY_PARTIAL = "TEMPORARY_PARTIAL"
    PERMANENT_TOTAL = "PERMANENT_TOTAL"
    PERMANENT_PARTIAL = "PERMANENT_PARTIAL"


class PaymentMethod(str, Enum):
    ACH = "ACH"
    WIRE = "WIRE"
    CHECK = "CHECK"
    BACS = "BACS"  # UK


class ClaimStatus(str, Enum):
    RECEIVED = "RECEIVED"
    PROCESSING = "PROCESSING"
    UNDER_REVIEW = "UNDER_REVIEW"
    ADDITIONAL_INFO_REQUIRED = "ADDITIONAL_INFO_REQUIRED"
    APPROVED = "APPROVED"
    PARTIALLY_APPROVED = "PARTIALLY_APPROVED"
    DENIED = "DENIED"
    PAID = "PAID"


class DocumentType(str, Enum):
    MEDICAL_BILL = "MEDICAL_BILL"
    POLICE_REPORT = "POLICE_REPORT"
    DEATH_CERTIFICATE = "DEATH_CERTIFICATE"
    PHYSICIAN_STATEMENT = "PHYSICIAN_STATEMENT"
    EMPLOYER_STATEMENT = "EMPLOYER_STATEMENT"
    ID_PROOF = "ID_PROOF"
    CLAIM_FORM = "CLAIM_FORM"
    OTHER = "OTHER"


class Channel(str, Enum):
    MENDIX_PORTAL = "MENDIX_PORTAL"
    MOBILE_APP = "MOBILE_APP"
    CALL_CENTER = "CALL_CENTER"
    WEB_PORTAL = "WEB_PORTAL"


# Nested Models
class Coordinates(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


class NationalIdentifier(BaseModel):
    type: str = Field(..., regex="^(SSN|NI_NUMBER|TAX_ID)$")
    value: str = Field(..., description="Masked format for security")


class ContactInformation(BaseModel):
    primaryPhone: str = Field(..., regex=r"^\+?[1-9]\d{1,14}$")
    email: Optional[EmailStr] = None
    preferredLanguage: str = Field(default="en-US", regex="^[a-z]{2}-[A-Z]{2}$")


class Address(BaseModel):
    street1: str = Field(..., max_length=200)
    street2: Optional[str] = Field(None, max_length=200)
    city: str = Field(..., max_length=100)
    stateProvince: Optional[str] = Field(None, max_length=100)
    postalCode: str = Field(..., max_length=20)
    country: str = Field(..., regex="^(US|UK)$")


class Employer(BaseModel):
    name: str = Field(..., max_length=200)
    occupation: str = Field(..., max_length=100)
    avgMonthlyEarnings: float = Field(..., gt=0)


class Locale(BaseModel):
    country: str = Field(..., regex="^(US|UK)$")
    state: Optional[str] = Field(None, max_length=100)
    regulatoryZone: Optional[str] = None


class PolicyHolder(BaseModel):
    policyNumber: str = Field(..., max_length=50)
    secondaryPolicyNumber: Optional[str] = Field(None, max_length=50)
    firstName: str = Field(..., max_length=100)
    middleName: Optional[str] = Field(None, max_length=100)
    lastName: str = Field(..., max_length=100)
    dateOfBirth: date
    gender: Gender
    nationalIdentifier: NationalIdentifier
    contactInformation: ContactInformation
    address: Address
    employer: Optional[Employer] = None


class Patient(BaseModel):
    firstName: str = Field(..., max_length=100)
    lastName: str = Field(..., max_length=100)
    dateOfBirth: date
    gender: Gender
    relationshipToPolicyHolder: str = Field(
        ..., 
        regex="^(SELF|SPOUSE|CHILD|DEPENDENT|OTHER)$"
    )


class IncidentLocation(BaseModel):
    description: str = Field(..., max_length=500)
    coordinates: Optional[Coordinates] = None


class WitnessInformation(BaseModel):
    name: str = Field(..., max_length=200)
    contactPhone: str = Field(..., regex=r"^\+?[1-9]\d{1,14}$")


class IncidentDetails(BaseModel):
    incidentDate: datetime
    incidentType: IncidentType
    incidentLocation: Optional[IncidentLocation] = None
    incidentDescription: str = Field(..., max_length=2000)
    workRelated: bool = False
    policeReportNumber: Optional[str] = Field(None, max_length=50)
    witnessInformation: Optional[List[WitnessInformation]] = None


class Diagnosis(BaseModel):
    code: str = Field(..., max_length=20, description="ICD-10/ICD-11 code")
    description: str = Field(..., max_length=500)


class TreatingPhysician(BaseModel):
    name: str = Field(..., max_length=200)
    npiNumber: str = Field(..., max_length=50, description="US: NPI, UK: GMC Number")
    specialty: Optional[str] = Field(None, max_length=100)
    phone: str = Field(..., regex=r"^\+?[1-9]\d{1,14}$")
    address: Optional[Address] = None


class HospitalInformation(BaseModel):
    name: str = Field(..., max_length=200)
    admissionDate: Optional[date] = None
    dischargeDate: Optional[date] = None
    daysConfined: Optional[int] = Field(None, ge=0)


class TreatmentDetails(BaseModel):
    firstTreatmentDate: date
    ongoingTreatment: bool = False
    expectedRecoveryDate: Optional[date] = None


class Disabilities(BaseModel):
    unableToWorkSince: Optional[date] = None
    returnToWorkDate: Optional[date] = None
    workStatus: Optional[WorkStatus] = None
    disabilityType: Optional[DisabilityType] = None


class MedicalInformation(BaseModel):
    diagnosis: List[Diagnosis]
    treatingPhysician: Optional[TreatingPhysician] = None
    hospitalInformation: Optional[HospitalInformation] = None
    treatmentDetails: Optional[TreatmentDetails] = None
    disabilities: Optional[Disabilities] = None


class ClaimedAmount(BaseModel):
    amount: float = Field(..., gt=0)
    currency: str = Field(..., regex="^(USD|GBP)$")


class ItemizedBill(BaseModel):
    serviceDate: date
    provider: str = Field(..., max_length=200)
    procedureCode: str = Field(..., max_length=20, description="CPT for US, OPCS for UK")
    amount: float = Field(..., gt=0)
    currency: str = Field(..., regex="^(USD|GBP)$")


class OtherInsurance(BaseModel):
    hasOtherCoverage: bool = False
    insurerName: Optional[str] = Field(None, max_length=200)
    policyNumber: Optional[str] = Field(None, max_length=50)


class AccountDetails(BaseModel):
    accountNumber: str = Field(..., description="Encrypted in storage")
    routingNumber: str = Field(..., description="US: ABA, UK: Sort Code")
    accountHolderName: str = Field(..., max_length=200)


class PaymentPreference(BaseModel):
    method: PaymentMethod
    accountDetails: Optional[AccountDetails] = None


class FinancialInformation(BaseModel):
    claimedAmount: ClaimedAmount
    itemizedBills: Optional[List[ItemizedBill]] = None
    otherInsurance: Optional[OtherInsurance] = None
    paymentPreference: Optional[PaymentPreference] = None


class SubmissionMetadata(BaseModel):
    submittedBy: str = Field(..., max_length=100)
    submissionTimestamp: datetime
    channel: Channel
    correlationId: UUID = Field(default_factory=uuid4)
    ipAddress: Optional[str] = Field(None, regex=r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$")
    userAgent: Optional[str] = Field(None, max_length=500)


class Attachment(BaseModel):
    documentType: DocumentType
    fileName: str = Field(..., max_length=255)
    fileSize: int = Field(..., gt=0)
    mimeType: str = Field(..., max_length=100)
    fileUrl: str = Field(..., max_length=1000)
    checksum: str = Field(..., max_length=64, description="SHA-256 hash")


class FraudDetection(BaseModel):
    riskScore: float = Field(..., ge=0, le=100)
    riskFactors: Optional[List[str]] = None
    requiresManualReview: bool = False


# Main Request Model
class TextBasedClaimRequest(BaseModel):
    claimType: ClaimType
    jurisdiction: Jurisdiction
    locale: Locale
    policyHolder: PolicyHolder
    patient: Optional[Patient] = None
    incidentDetails: IncidentDetails
    medicalInformation: Optional[MedicalInformation] = None
    financialInformation: Optional[FinancialInformation] = None
    submissionMetadata: SubmissionMetadata
    attachments: Optional[List[Attachment]] = None
    fraudDetection: Optional[FraudDetection] = None
    
    @validator("patient")
    def validate_patient(cls, v, values):
        """If patient is not provided, assume policyholder is the patient"""
        if v is None and "policyHolder" in values:
            ph = values["policyHolder"]
            return Patient(
                firstName=ph.firstName,
                lastName=ph.lastName,
                dateOfBirth=ph.dateOfBirth,
                gender=ph.gender,
                relationshipToPolicyHolder="SELF"
            )
        return v


# Response Models
class AIProcessing(BaseModel):
    agentAssigned: str
    automationLevel: str = Field(..., regex="^(FULLY_AUTOMATED|HYBRID|MANUAL_REVIEW)$")
    confidenceScore: float = Field(..., ge=0, le=1)


class NextStep(BaseModel):
    action: str
    dueDate: Optional[date] = None
    responsible: str = Field(..., regex="^(CLAIMANT|PHYSICIAN|EMPLOYER|INSURER)$")


class ErrorDetail(BaseModel):
    code: str
    message: str
    field: Optional[str] = None
    severity: str = Field(..., regex="^(ERROR|WARNING|INFO)$")


class ClaimResponse(BaseModel):
    claimId: UUID
    claimNumber: str
    status: ClaimStatus
    submissionTimestamp: datetime
    estimatedProcessingTime: str = "3-5 business days"
    aiProcessing: Optional[AIProcessing] = None
    nextSteps: Optional[List[NextStep]] = None
    errors: Optional[List[ErrorDetail]] = None


# OCR Models
class OCRRequest(BaseModel):
    documentType: DocumentType
    jurisdiction: Jurisdiction
    policyNumber: Optional[str] = None
    correlationId: Optional[UUID] = None


class ExtractedData(BaseModel):
    confidence: float = Field(..., ge=0, le=1)
    fields: Dict[str, Any]
    requiresValidation: List[str] = []


class OCRResponse(BaseModel):
    ocrJobId: UUID
    status: str = Field(..., regex="^(QUEUED|PROCESSING|COMPLETED|FAILED)$")
    extractedData: Optional[ExtractedData] = None
    suggestedClaimType: Optional[ClaimType] = None
    claimPreview: Optional[Dict[str, Any]] = None
