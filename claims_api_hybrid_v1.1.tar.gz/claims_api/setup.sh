#!/bin/bash
# XYZ Claims Processing API - Universal Setup Script
# Supports: Windows 11 (Git Bash/WSL), Linux, macOS
# Automatically handles all dependencies including Rust

set -e

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_header() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║  $1${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════╝${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Detect operating system
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        OS="linux"
        if grep -qi microsoft /proc/version 2>/dev/null; then
            OS="wsl"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
        OS="windows"
    else
        OS="unknown"
    fi
    echo "$OS"
}

# Check if running in WSL
is_wsl() {
    grep -qi microsoft /proc/version 2>/dev/null && return 0 || return 1
}

# Install Rust and Cargo
install_rust() {
    print_info "Checking for Rust installation..."
    
    if command -v rustc >/dev/null 2>&1 && command -v cargo >/dev/null 2>&1; then
        RUST_VERSION=$(rustc --version | cut -d' ' -f2)
        print_success "Rust already installed: $RUST_VERSION"
        return 0
    fi
    
    print_warning "Rust not found. Installing Rust and Cargo..."
    
    case $DETECTED_OS in
        linux|wsl|macos)
            # Use rustup for Unix-like systems
            curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
            
            # Source cargo environment
            if [ -f "$HOME/.cargo/env" ]; then
                source "$HOME/.cargo/env"
            fi
            ;;
        windows)
            print_warning "Please install Rust manually on Windows:"
            print_info "1. Download from: https://rustup.rs/"
            print_info "2. Run the installer"
            print_info "3. Restart Git Bash/PowerShell"
            print_info "4. Run this script again"
            exit 1
            ;;
    esac
    
    # Verify installation
    if command -v rustc >/dev/null 2>&1 && command -v cargo >/dev/null 2>&1; then
        RUST_VERSION=$(rustc --version)
        print_success "Rust installed successfully: $RUST_VERSION"
    else
        print_error "Rust installation failed"
        exit 1
    fi
}

# Install system dependencies
install_system_dependencies() {
    print_info "Installing system dependencies..."
    
    case $DETECTED_OS in
        linux)
            if command -v apt-get >/dev/null 2>&1; then
                # Debian/Ubuntu
                print_info "Detected Debian/Ubuntu system"
                sudo apt-get update
                sudo apt-get install -y \
                    build-essential \
                    libssl-dev \
                    libffi-dev \
                    python3-dev \
                    pkg-config \
                    curl \
                    git \
                    postgresql-client \
                    redis-tools
                print_success "System dependencies installed (apt)"
            elif command -v yum >/dev/null 2>&1; then
                # RHEL/CentOS/Fedora
                print_info "Detected RHEL/CentOS/Fedora system"
                sudo yum install -y \
                    gcc \
                    gcc-c++ \
                    openssl-devel \
                    libffi-devel \
                    python3-devel \
                    pkgconfig \
                    curl \
                    git \
                    postgresql \
                    redis
                print_success "System dependencies installed (yum)"
            else
                print_warning "Unknown Linux distribution. Skipping system dependencies."
                print_info "You may need to install: build-essential, libssl-dev, libffi-dev, python3-dev"
            fi
            ;;
        wsl)
            print_info "Detected WSL environment"
            sudo apt-get update
            sudo apt-get install -y \
                build-essential \
                libssl-dev \
                libffi-dev \
                python3-dev \
                pkg-config \
                curl \
                git \
                postgresql-client \
                redis-tools
            print_success "System dependencies installed (WSL)"
            ;;
        macos)
            if ! command -v brew >/dev/null 2>&1; then
                print_warning "Homebrew not found. Installing Homebrew..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            
            print_info "Installing dependencies via Homebrew..."
            brew install \
                openssl \
                libffi \
                pkg-config \
                postgresql \
                redis
            print_success "System dependencies installed (Homebrew)"
            ;;
        windows)
            print_warning "Running on Windows. System dependencies:"
            print_info "1. Ensure you have Microsoft C++ Build Tools installed"
            print_info "   Download: https://visualstudio.microsoft.com/visual-cpp-build-tools/"
            print_info "2. OpenSSL: included with Python for Windows"
            print_info "3. For Docker Desktop: https://docs.docker.com/desktop/install/windows-install/"
            ;;
    esac
}

# Install Python dependencies with cryptography support
install_python_dependencies() {
    print_info "Installing Python dependencies..."
    
    # Upgrade pip
    python3 -m pip install --upgrade pip setuptools wheel
    
    # Install cryptography with Rust backend
    if [ "$DETECTED_OS" = "windows" ]; then
        # Windows may need pre-built wheels
        pip install cryptography --only-binary :all:
    else
        pip install cryptography
    fi
    
    # Install remaining dependencies
    pip install -r requirements.txt
    
    print_success "Python dependencies installed"
}

# Main setup
print_header "XYZ Claims Processing API - Universal Setup"
echo ""

# Detect OS
DETECTED_OS=$(detect_os)
print_info "Detected OS: $DETECTED_OS"
echo ""

# Check prerequisites
print_header "Checking Prerequisites"
echo ""

# Python check
if ! command -v python3 >/dev/null 2>&1; then
    print_error "Python 3 is required but not installed"
    case $DETECTED_OS in
        linux|wsl)
            print_info "Install: sudo apt-get install python3 python3-pip python3-venv"
            ;;
        macos)
            print_info "Install: brew install python3"
            ;;
        windows)
            print_info "Download from: https://www.python.org/downloads/"
            ;;
    esac
    exit 1
else
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    print_success "Python found: $PYTHON_VERSION"
    
    # Check Python version
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d'.' -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d'.' -f2)
    
    if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
        print_warning "Python 3.11+ recommended. You have $PYTHON_VERSION"
    fi
fi

# Docker check
if command -v docker >/dev/null 2>&1; then
    print_success "Docker found: $(docker --version)"
    DOCKER_AVAILABLE=true
else
    print_warning "Docker not found. Docker setup will be skipped."
    print_info "Install Docker: https://docs.docker.com/get-docker/"
    DOCKER_AVAILABLE=false
fi

# Docker Compose check
if command -v docker-compose >/dev/null 2>&1 || docker compose version >/dev/null 2>&1; then
    print_success "Docker Compose available"
else
    print_warning "Docker Compose not found"
    DOCKER_AVAILABLE=false
fi

echo ""

# Install Rust and system dependencies
print_header "Installing System Dependencies"
echo ""

install_rust
echo ""
install_system_dependencies
echo ""

# Setup mode selection
print_header "Setup Mode Selection"
echo ""
echo "Select setup mode:"
echo "1. Docker (Recommended - Easiest)"
echo "2. Local (Manual - For development)"
echo "3. Azure (Cloud deployment)"
echo ""
read -p "Enter choice [1-3]: " setup_mode

# Environment configuration
print_header "Environment Configuration"
echo ""

if [ ! -f .env ]; then
    cp .env.example .env
    print_success "Created .env file from template"
    print_warning "IMPORTANT: Edit .env and add your API keys!"
    echo ""
    print_info "Required keys:"
    echo "  - OPENAI_API_KEY=sk-..."
    echo "  - ANTHROPIC_API_KEY=sk-ant-..."
    echo ""
    
    # Prompt for API keys
    read -p "Would you like to enter API keys now? (y/n): " enter_keys
    if [ "$enter_keys" = "y" ] || [ "$enter_keys" = "Y" ]; then
        read -p "Enter OpenAI API key: " OPENAI_KEY
        read -p "Enter Anthropic API key: " ANTHROPIC_KEY
        
        # Update .env file
        if [ -n "$OPENAI_KEY" ]; then
            sed -i.bak "s|OPENAI_API_KEY=.*|OPENAI_API_KEY=$OPENAI_KEY|" .env
            print_success "OpenAI API key configured"
        fi
        
        if [ -n "$ANTHROPIC_KEY" ]; then
            sed -i.bak "s|ANTHROPIC_API_KEY=.*|ANTHROPIC_API_KEY=$ANTHROPIC_KEY|" .env
            print_success "Anthropic API key configured"
        fi
        
        rm -f .env.bak
    fi
else
    print_info ".env file already exists"
fi

echo ""

# Docker setup
if [ "$setup_mode" = "1" ]; then
    if [ "$DOCKER_AVAILABLE" = false ]; then
        print_error "Docker is not available. Please install Docker first."
        exit 1
    fi
    
    print_header "Docker Setup"
    echo ""
    
    # Build and start containers
    print_info "Building and starting Docker containers..."
    
    if docker compose version >/dev/null 2>&1; then
        # Docker Compose V2
        docker compose up -d --build
    else
        # Docker Compose V1
        docker-compose up -d --build
    fi
    
    echo ""
    print_info "Waiting for services to initialize..."
    sleep 10
    
    # Check container status
    if docker compose version >/dev/null 2>&1; then
        docker compose ps
    else
        docker-compose ps
    fi
    
    echo ""
    print_success "Docker setup completed!"
    echo ""
    print_header "Services Available"
    echo ""
    echo "  🌐 API:           http://localhost:8000"
    echo "  📚 API Docs:      http://localhost:8000/api/docs"
    echo "  📖 ReDoc:         http://localhost:8000/api/redoc"
    echo "  ❤️  Health Check:  http://localhost:8000/api/health"
    echo ""
    print_header "Useful Commands"
    echo ""
    echo "  View logs:       docker compose logs -f api"
    echo "  Stop services:   docker compose down"
    echo "  Restart:         docker compose restart"
    echo "  Shell access:    docker compose exec api bash"
    echo ""

# Local setup
elif [ "$setup_mode" = "2" ]; then
    print_header "Local Development Setup"
    echo ""
    
    # Create virtual environment
    if [ ! -d "venv" ]; then
        print_info "Creating virtual environment..."
        python3 -m venv venv
        print_success "Virtual environment created"
    else
        print_info "Virtual environment already exists"
    fi
    
    # Activate virtual environment
    print_info "Activating virtual environment..."
    
    case $DETECTED_OS in
        windows)
            source venv/Scripts/activate 2>/dev/null || . venv/Scripts/activate
            ;;
        *)
            source venv/bin/activate
            ;;
    esac
    
    # Install dependencies
    install_python_dependencies
    
    echo ""
    print_success "Local setup completed!"
    echo ""
    print_header "Before Running the API"
    echo ""
    print_warning "Make sure you have the following services running:"
    echo "  - PostgreSQL on localhost:5432"
    echo "  - Redis on localhost:6379"
    echo ""
    print_info "Or use Docker for services only:"
    echo "  docker run -d -p 5432:5432 -e POSTGRES_PASSWORD=postgres postgres:15"
    echo "  docker run -d -p 6379:6379 redis:7"
    echo ""
    print_header "Start the API"
    echo ""
    
    case $DETECTED_OS in
        windows)
            echo "  source venv/Scripts/activate"
            ;;
        *)
            echo "  source venv/bin/activate"
            ;;
    esac
    
    echo "  uvicorn app.main:app --reload"
    echo ""
    echo "  Or with Gunicorn (production):"
    echo "  gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker"
    echo ""

# Azure setup
elif [ "$setup_mode" = "3" ]; then
    print_header "Azure Deployment Setup"
    echo ""
    
    # Check Azure CLI
    if ! command -v az >/dev/null 2>&1; then
        print_error "Azure CLI is required for cloud deployment"
        print_info "Install: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    fi
    
    print_success "Azure CLI found: $(az version -o tsv | head -1)"
    
    # Check login status
    if ! az account show >/dev/null 2>&1; then
        print_warning "Not logged in to Azure"
        print_info "Logging in..."
        az login
    else
        print_success "Already logged in to Azure"
        ACCOUNT_NAME=$(az account show --query name -o tsv)
        print_info "Active subscription: $ACCOUNT_NAME"
    fi
    
    echo ""
    read -p "Enter resource group name [xyz-claims-rg]: " RESOURCE_GROUP
    RESOURCE_GROUP=${RESOURCE_GROUP:-xyz-claims-rg}
    
    read -p "Enter environment [production]: " ENVIRONMENT
    ENVIRONMENT=${ENVIRONMENT:-production}
    
    read -p "Enter Azure region [eastus]: " LOCATION
    LOCATION=${LOCATION:-eastus}
    
    read -sp "Enter PostgreSQL admin password: " PG_PASSWORD
    echo ""
    
    # Create resource group
    print_info "Creating resource group: $RESOURCE_GROUP..."
    az group create --name "$RESOURCE_GROUP" --location "$LOCATION"
    
    # Deploy infrastructure
    print_info "Deploying Azure infrastructure..."
    az deployment group create \
        --resource-group "$RESOURCE_GROUP" \
        --template-file azure-deployment.bicep \
        --parameters environment="$ENVIRONMENT" postgreSQLPassword="$PG_PASSWORD"
    
    echo ""
    print_success "Azure infrastructure deployed!"
    echo ""
    print_header "Next Steps"
    echo ""
    echo "1. Get App Service URL from Azure Portal"
    echo "2. Configure application settings:"
    echo "   az webapp config appsettings set \\"
    echo "     --resource-group $RESOURCE_GROUP \\"
    echo "     --name xyz-claims-api-$ENVIRONMENT \\"
    echo "     --settings OPENAI_API_KEY=sk-... ANTHROPIC_API_KEY=sk-ant-..."
    echo ""
    echo "3. Deploy application:"
    echo "   az webapp up --name xyz-claims-api-$ENVIRONMENT --resource-group $RESOURCE_GROUP"
    echo ""
fi

# Post-setup tasks
echo ""
print_header "Post-Setup Checklist"
echo ""

print_info "1. API Keys Configuration (.env):"
echo "   ✓ OPENAI_API_KEY      - Required for GPT-4o estimation"
echo "   ✓ ANTHROPIC_API_KEY   - Required for Claude estimation"
echo "   ✓ SECRET_KEY          - Change to strong random string"
echo ""

print_info "2. Test the API:"
echo "   ✓ Run test suite:      python test_fnol_api.py"
echo "   ✓ Unit tests:          pytest"
echo "   ✓ Health check:        curl http://localhost:8000/api/health"
echo "   ✓ API docs:            http://localhost:8000/api/docs"
echo ""

print_info "3. Security Review:"
echo "   ✓ Update OAuth credentials in .env"
echo "   ✓ Configure CORS origins"
echo "   ✓ Review security documentation: SECURITY_ARCHITECTURE.md"
echo ""

print_info "4. For Mendix Integration:"
echo "   ✓ Share FNOL_API_SCHEMA.json"
echo "   ✓ Provide OAuth credentials"
echo "   ✓ Configure webhook endpoints"
echo "   ✓ Review: FNOL_API_DOCUMENTATION.md"
echo ""

# Platform-specific notes
case $DETECTED_OS in
    windows)
        print_header "Windows-Specific Notes"
        echo ""
        print_info "• Use Git Bash or WSL for best experience"
        print_info "• Activate venv: source venv/Scripts/activate"
        print_info "• Docker Desktop must be running"
        print_info "• Firewall may need configuration for port 8000"
        echo ""
        ;;
    wsl)
        print_header "WSL-Specific Notes"
        echo ""
        print_info "• Access API from Windows: http://localhost:8000"
        print_info "• Docker Desktop with WSL2 backend recommended"
        print_info "• Files in /mnt/c/ may have slower I/O"
        echo ""
        ;;
    macos)
        print_header "macOS-Specific Notes"
        echo ""
        print_info "• Firewall: System Settings → Network → Firewall"
        print_info "• Docker Desktop must be running"
        print_info "• Use Homebrew for additional tools"
        echo ""
        ;;
esac

print_header "Setup Complete!"
echo ""
print_success "All dependencies installed and configured!"
print_info "Check README_HYBRID.md for detailed documentation"
echo ""
print_info "Quick test command:"
echo "  python test_fnol_api.py"
echo ""

# Create a helpful next-steps file
cat > NEXT_STEPS.txt << 'EOF'
╔══════════════════════════════════════════════════════════╗
║       XYZ CLAIMS API - NEXT STEPS                        ║
╚══════════════════════════════════════════════════════════╝

1. CONFIGURE API KEYS
   Edit .env and add your keys:
   - OPENAI_API_KEY=sk-...
   - ANTHROPIC_API_KEY=sk-ant-...

2. START THE API
   Docker:  docker compose up -d
   Local:   source venv/bin/activate && uvicorn app.main:app --reload

3. TEST THE API
   Run:     python test_fnol_api.py
   Docs:    http://localhost:8000/api/docs
   Health:  curl http://localhost:8000/api/health

4. REVIEW DOCUMENTATION
   - README_HYBRID.md              (Complete guide)
   - FNOL_API_DOCUMENTATION.md     (API reference)
   - SECURITY_ARCHITECTURE.md      (Security details)

5. INTEGRATION
   - Share OAuth credentials with Mendix
   - Provide FNOL_API_SCHEMA.json
   - Configure webhook endpoints

For support: api-support@xyzconsulting.com

Target Go-Live: January 16, 2025
EOF

print_success "Created NEXT_STEPS.txt for quick reference"
echo ""
