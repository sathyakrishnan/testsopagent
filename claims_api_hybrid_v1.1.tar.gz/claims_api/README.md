# XYZ Claims Processing API

Enterprise-grade insurance claims processing API with AI-powered automation, supporting both US and UK jurisdictions.

## 🎯 Overview

This production-ready API provides:
- **Text-based claim submission** from FNOL (First Notice of Loss) systems
- **OCR-based claim processing** for scanned documents
- **AI-powered claim analysis** with multi-agent orchestration
- **Automated fraud detection** and risk assessment
- **Compliance validation** for US (HIPAA, GLBA) and UK (GDPR, FCA) regulations
- **Seamless Mendix integration** via REST APIs

## 🏗️ Architecture

### Technology Stack
- **Framework**: FastAPI 0.109+
- **AI/ML**: Anthropic Claude Sonnet 4.5, LangChain
- **OCR**: Azure Form Recognizer
- **Database**: PostgreSQL 15
- **Cache**: Redis 7
- **Task Queue**: Celery
- **Container**: Docker
- **Cloud**: Azure (App Service, Storage, Key Vault)

### AI Agent System
Multi-agent orchestration for intelligent claim processing:
1. **Medical Review Agent**: Validates diagnoses, procedures, and medical necessity
2. **Fraud Detection Agent**: Analyzes patterns and risk indicators
3. **Compliance Agent**: Ensures regulatory adherence (HIPAA/GDPR/FCA)
4. **Financial Analyst Agent**: Validates billing and calculates benefits

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Docker & Docker Compose
- Azure subscription (for cloud deployment)
- Anthropic API key

### Local Development Setup

1. **Clone repository**
```bash
git clone <repository-url>
cd claims_api
```

2. **Set environment variables**
```bash
cp .env.example .env
# Edit .env with your credentials
export ANTHROPIC_API_KEY=your_key_here
```

3. **Start services with Docker Compose**
```bash
docker-compose up -d
```

4. **Access API**
- API: http://localhost:8000
- API Docs: http://localhost:8000/api/docs
- Flower (Celery): http://localhost:5555

### Manual Setup (without Docker)

1. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Set up PostgreSQL and Redis**
```bash
# Using Homebrew on macOS
brew install postgresql@15 redis
brew services start postgresql@15
brew services start redis
```

4. **Run database migrations**
```bash
alembic upgrade head
```

5. **Start API server**
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## 📡 API Endpoints

### Authentication
```http
POST /api/v1/auth/token
Content-Type: application/x-www-form-urlencoded

username=mendix_client&password=secret&scope=claims:read claims:write
```

**Response:**
```json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "token_type": "bearer",
  "expires_in": 1800
}
```

### Submit Text-Based Claim
```http
POST /api/v1/claims/text
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body:** See `MENDIX_API_SCHEMA.json` for complete schema

**Response:**
```json
{
  "claimId": "550e8400-e29b-41d4-a716-446655440000",
  "claimNumber": "CLM-2024-US-FL-001234",
  "status": "PROCESSING",
  "submissionTimestamp": "2024-11-20T10:30:00Z",
  "estimatedProcessingTime": "3-5 business days",
  "aiProcessing": {
    "agentAssigned": "claims_adjuster_ai",
    "automationLevel": "HYBRID",
    "confidenceScore": 0.87
  }
}
```

### Submit OCR-Based Claim
```http
POST /api/v1/claims/ocr
Authorization: Bearer {access_token}
Content-Type: multipart/form-data

file=@claim_form.pdf
documentType=CLAIM_FORM
jurisdiction=US
policyNumber=POL-US-2024-123456
```

**Response:**
```json
{
  "ocrJobId": "660e8400-e29b-41d4-a716-446655440001",
  "status": "COMPLETED",
  "extractedData": {
    "confidence": 0.92,
    "fields": { ... },
    "requiresValidation": ["date_of_birth"]
  },
  "suggestedClaimType": "ACCIDENT",
  "claimPreview": { ... }
}
```

### Get Claim Status
```http
GET /api/v1/claims/{claimId}/status
Authorization: Bearer {access_token}
```

## 🔐 Security

### Authentication & Authorization
- OAuth 2.0 with JWT tokens
- Scope-based access control: `claims:read`, `claims:write`, `claims:admin`
- API key support for service-to-service communication

### Data Protection
- TLS 1.3 for data in transit
- AES-256 encryption for data at rest
- Field-level encryption for PII (SSN, account numbers)
- HIPAA and GDPR compliant data handling

### Rate Limiting
- Text claims: 100 requests/minute
- OCR claims: 20 requests/minute
- Status queries: 500 requests/minute

## 🧪 Testing

### Run Tests
```bash
# All tests
pytest

# With coverage
pytest --cov=app --cov-report=html

# Specific test file
pytest tests/test_claims_api.py -v

# Integration tests only
pytest -m integration
```

### Test Credentials (Development)
```
Username: mendix_client
Password: secret
Scopes: claims:read claims:write
```

## 📊 Monitoring & Observability

### Metrics
- Prometheus metrics at `/metrics`
- Application Insights integration
- Custom business metrics (claim processing time, fraud detection rate)

### Logging
- Structured JSON logging with `structlog`
- Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
- Correlation IDs for request tracing

### Health Checks
- `/api/health` - Basic health check
- `/api/health/detailed` - System metrics
- `/ready` - Kubernetes readiness probe
- `/live` - Kubernetes liveness probe

## 🚢 Deployment

### Azure Deployment

1. **Deploy infrastructure**
```bash
az deployment group create \
  --resource-group xyz-claims-rg \
  --template-file azure-deployment.bicep \
  --parameters environment=production postgreSQLPassword=<secure-password>
```

2. **Configure CI/CD**
- GitHub Actions workflow included
- Azure DevOps pipeline template available

3. **Deploy application**
```bash
az webapp up \
  --name xyz-claims-api-production \
  --resource-group xyz-claims-rg \
  --runtime "PYTHON:3.11"
```

### Environment Variables

Required variables for production:
```bash
# Application
ENVIRONMENT=production
SECRET_KEY=<strong-secret-key>
DEBUG=false

# Database
DATABASE_URL=postgresql://user:pass@host:5432/claims_db

# Azure Services
AZURE_STORAGE_CONNECTION_STRING=<connection-string>
AZURE_KEYVAULT_URL=https://xyz-claims-kv.vault.azure.net/
AZURE_FORM_RECOGNIZER_ENDPOINT=<endpoint>
AZURE_FORM_RECOGNIZER_KEY=<key>
AZURE_APP_INSIGHTS_KEY=<key>

# AI
ANTHROPIC_API_KEY=<api-key>

# OAuth
OAUTH_TOKEN_URL=<token-url>
OAUTH_CLIENT_ID=<client-id>
OAUTH_CLIENT_SECRET=<client-secret>

# Mendix Integration
MENDIX_WEBHOOK_URL=<webhook-url>
MENDIX_API_KEY=<api-key>
```

## 🤝 Mendix Integration

### Setup Steps

1. **Obtain API credentials**
```bash
# Contact XYZ API team for:
- OAuth Client ID
- OAuth Client Secret
- API Base URL
```

2. **Configure Mendix REST service**
- Import OpenAPI specification from `/api/openapi.json`
- Configure OAuth 2.0 authentication
- Set base URL: `https://api.xyzconsulting.com/claims/v1`

3. **Implement FNOL flow**
```
User submits FNOL in Mendix
   ↓
Mendix validates and enriches data
   ↓
POST to /api/v1/claims/text
   ↓
Receive claim ID and status
   ↓
Store claim ID in Mendix
   ↓
Poll /api/v1/claims/{claimId}/status or receive webhook
```

### Webhook Configuration
Configure Mendix to receive claim status updates:
```json
{
  "webhookUrl": "https://mendix.xyzconsulting.com/webhooks/claim-status",
  "events": ["claim.status.changed", "claim.approved", "claim.denied"]
}
```

## 📝 Sample Payloads

Complete request/response examples are in `MENDIX_API_SCHEMA.json`.

### US Accident Claim Example
```json
{
  "claimType": "ACCIDENT",
  "jurisdiction": "US",
  "policyHolder": {
    "policyNumber": "POL-US-2024-123456",
    "firstName": "John",
    "lastName": "Smith",
    "dateOfBirth": "1985-06-15",
    ...
  },
  ...
}
```

### UK Disability Claim Example
```json
{
  "claimType": "DISABILITY",
  "jurisdiction": "UK",
  "policyHolder": {
    "policyNumber": "POL-UK-2024-987654",
    "nationalIdentifier": {
      "type": "NI_NUMBER",
      "value": "XX123456X"
    },
    ...
  },
  ...
}
```

## 🛠️ Development

### Code Style
- **Black** for Python formatting
- **Flake8** for linting
- **MyPy** for type checking
- **Pre-commit hooks** for automated checks

```bash
# Format code
black app/

# Run linter
flake8 app/

# Type checking
mypy app/
```

### Project Structure
```
claims_api/
├── app/
│   ├── api/v1/          # API endpoints
│   ├── agents/          # AI agent system
│   ├── core/            # Configuration, security
│   ├── models/          # Pydantic schemas
│   ├── services/        # Business logic
│   └── main.py          # FastAPI application
├── tests/               # Test suite
├── config/              # Configuration files
├── docs/                # Documentation
├── scripts/             # Utility scripts
├── Dockerfile           # Container definition
├── docker-compose.yml   # Local development
└── requirements.txt     # Python dependencies
```

## 📞 Support

### For Mendix Integration
- **API Documentation**: `/api/docs`
- **Support Email**: api-support@xyzconsulting.com
- **Slack Channel**: #xyz-claims-api

### For XYZ Team
- **Technical Lead**: Sathya (sathya@xyzconsulting.com)
- **Architecture Review**: Weekly Fridays 2pm EST
- **Incident Response**: PagerDuty rotation

## 📄 License

Proprietary - XYZ Consulting © 2024

## 🔄 Changelog

### Version 1.0.0 (2024-11-20)
- Initial production release
- Text-based and OCR claim submission
- Multi-agent AI orchestration
- US and UK jurisdiction support
- Mendix REST integration
- Comprehensive test coverage
- Azure deployment ready

---

**Built with ❤️ by XYZ Consulting AI Platform Team**
