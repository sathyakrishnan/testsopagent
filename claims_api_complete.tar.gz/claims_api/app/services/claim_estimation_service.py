"""
FNOL Claims Estimation Service
Uses GPT-4o for intelligent claim estimation based on FNOL data
"""
from typing import Dict, Any, List, Optional
from openai import AsyncOpenAI
import structlog
from datetime import datetime
import json

from app.core.config import settings
from app.models.fnol_schemas import FNOLClaimRequest

logger = structlog.get_logger(__name__)


class ClaimEstimationService:
    """Intelligent claim estimation using GPT-4o"""
    
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = "gpt-4o"  # GPT-4 Omni for comprehensive analysis
        
    async def estimate_claim(
        self, 
        fnol_data: FNOLClaimRequest
    ) -> Dict[str, Any]:
        """
        Generate comprehensive claim estimate using GPT-4o
        Returns estimated costs, severity, processing recommendations
        """
        
        logger.info(
            "claim_estimation_started",
            claim_type=fnol_data.claimType,
            jurisdiction=fnol_data.jurisdiction,
            incident_type=fnol_data.incidentDetails.incidentType
        )
        
        try:
            # Build comprehensive prompt for GPT-4o
            estimation_prompt = self._build_estimation_prompt(fnol_data)
            
            # Call GPT-4o with structured output
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": self._get_system_prompt(fnol_data.jurisdiction)
                    },
                    {
                        "role": "user",
                        "content": estimation_prompt
                    }
                ],
                temperature=0.3,  # Lower temperature for consistent estimates
                max_tokens=2000,
                response_format={"type": "json_object"}
            )
            
            # Parse GPT-4o response
            estimation = json.loads(response.choices[0].message.content)
            
            # Add metadata
            estimation['meta'] = {
                'model': self.model,
                'timestamp': datetime.utcnow().isoformat(),
                'prompt_tokens': response.usage.prompt_tokens,
                'completion_tokens': response.usage.completion_tokens,
                'total_tokens': response.usage.total_tokens
            }
            
            logger.info(
                "claim_estimation_completed",
                estimated_amount=estimation.get('estimated_total_cost'),
                severity=estimation.get('severity_assessment'),
                confidence=estimation.get('confidence_score')
            )
            
            return estimation
            
        except Exception as e:
            logger.error("claim_estimation_failed", error=str(e), exc_info=True)
            return self._fallback_estimation(fnol_data)
    
    def _get_system_prompt(self, jurisdiction: str) -> str:
        """Get jurisdiction-specific system prompt"""
        
        base_prompt = """You are an expert insurance claims adjuster with 20+ years of experience 
in evaluating First Notice of Loss (FNOL) claims. Your role is to provide accurate, data-driven 
claim cost estimates based on initial incident information.

You must respond ONLY with valid JSON in the following structure:
{
  "estimated_total_cost": {
    "amount": <number>,
    "currency": "<USD or GBP>",
    "range": {"min": <number>, "max": <number>}
  },
  "cost_breakdown": {
    "medical_expenses": <number>,
    "property_damage": <number>,
    "lost_wages": <number>,
    "other_costs": <number>
  },
  "severity_assessment": "<MINOR|MODERATE|SEVERE|CATASTROPHIC>",
  "confidence_score": <0-1>,
  "estimated_settlement_time": "<timeframe>",
  "recommended_reserve": {
    "amount": <number>,
    "justification": "<string>"
  },
  "risk_factors": ["<array of strings>"],
  "red_flags": ["<array of strings>"],
  "next_steps": ["<array of strings>"],
  "similar_claims_analysis": "<string>",
  "special_considerations": ["<array of strings>"]
}"""

        jurisdiction_guidance = {
            "US": """
Consider US-specific factors:
- Average medical costs in the US (ER visit: $1,500-$3,000)
- Vehicle repair costs (average: $3,000-$10,000 for moderate damage)
- Lost wages calculation (average US income)
- Liability limits and tort system
- State-specific regulations
- Attorney involvement likelihood
- Workers' compensation if applicable""",
            
            "UK": """
Consider UK-specific factors:
- NHS coverage (most medical costs covered)
- Private medical treatment costs if applicable
- Vehicle repair costs in GBP
- UK compensation culture (typically lower than US)
- No-fault system considerations
- Solicitor involvement patterns
- UK personal injury tariffs"""
        }
        
        return base_prompt + "\n\n" + jurisdiction_guidance.get(jurisdiction, "")
    
    def _build_estimation_prompt(self, fnol_data: FNOLClaimRequest) -> str:
        """Build comprehensive estimation prompt from FNOL data"""
        
        prompt_parts = [
            "# FNOL Claim Estimation Request\n",
            f"**Claim Type:** {fnol_data.claimType}",
            f"**Jurisdiction:** {fnol_data.jurisdiction}",
            f"**Incident Type:** {fnol_data.incidentDetails.incidentType}\n",
            
            "## Incident Details",
            f"**Date/Time:** {fnol_data.incidentDetails.incidentDate}",
            f"**Location:** {self._format_location(fnol_data)}",
            f"**Description:** {fnol_data.incidentDetails.incidentDescription}\n"
        ]
        
        # Injury information
        if fnol_data.incidentDetails.injuriesReported:
            prompt_parts.append("## Reported Injuries")
            for injury in fnol_data.incidentDetails.injuriesReported:
                prompt_parts.append(f"- {injury}")
            prompt_parts.append("")
        
        # Medical care status
        if fnol_data.immediateActions and fnol_data.immediateActions.currentMedicalCare:
            care = fnol_data.immediateActions.currentMedicalCare
            prompt_parts.append("## Current Medical Status")
            prompt_parts.append(f"- Receiving treatment: {care.receivingTreatment}")
            if care.location:
                prompt_parts.append(f"- Location: {care.location}")
            if care.admittedToHospital is not None:
                prompt_parts.append(f"- Admitted to hospital: {care.admittedToHospital}")
            prompt_parts.append("")
        
        # Vehicle damage (if applicable)
        if (fnol_data.immediateActions and 
            fnol_data.immediateActions.vehicleDetails):
            vehicle = fnol_data.immediateActions.vehicleDetails
            prompt_parts.append("## Vehicle Damage")
            if vehicle.estimatedDamage:
                prompt_parts.append(f"- Damage level: {vehicle.estimatedDamage}")
            if vehicle.vehicleDriveable is not None:
                prompt_parts.append(f"- Vehicle driveable: {vehicle.vehicleDriveable}")
            prompt_parts.append("")
        
        # Emergency services
        if fnol_data.incidentDetails.emergencyServicesInvolved:
            services = fnol_data.incidentDetails.emergencyServicesInvolved
            prompt_parts.append("## Emergency Services")
            if services.policeNotified:
                prompt_parts.append(f"- Police notified: Yes")
                if services.policeReportNumber:
                    prompt_parts.append(f"- Report #: {services.policeReportNumber}")
            if services.ambulanceCalled:
                prompt_parts.append("- Ambulance called: Yes")
            prompt_parts.append("")
        
        # Third party involvement
        if (fnol_data.thirdPartyInformation and 
            fnol_data.thirdPartyInformation.thirdPartyInvolved):
            prompt_parts.append("## Third Party Involved")
            prompt_parts.append("- Yes, third party involved")
            if fnol_data.thirdPartyInformation.thirdPartyDetails:
                details = fnol_data.thirdPartyInformation.thirdPartyDetails
                if details.insuranceCompany:
                    prompt_parts.append(f"- Their insurance: {details.insuranceCompany}")
            prompt_parts.append("")
        
        # Work related
        if fnol_data.incidentDetails.workRelated:
            prompt_parts.append("## Additional Context")
            prompt_parts.append("- This is a work-related incident (Workers' Compensation may apply)")
            prompt_parts.append("")
        
        # Urgency level
        if fnol_data.submissionMetadata.urgencyLevel:
            prompt_parts.append(f"**Urgency Level:** {fnol_data.submissionMetadata.urgencyLevel}\n")
        
        prompt_parts.append("""
Based on this FNOL information, provide:
1. Estimated total claim cost with range (min-max)
2. Detailed cost breakdown by category
3. Severity assessment
4. Confidence score in your estimate (0-1)
5. Estimated time to settle
6. Recommended reserve amount
7. Key risk factors identified
8. Any red flags for potential fraud or complications
9. Recommended next steps for claim processing
10. Analysis of similar historical claims
11. Special considerations for this case

Remember to consider jurisdiction-specific factors and provide realistic estimates based on current market rates.
""")
        
        return "\n".join(prompt_parts)
    
    def _format_location(self, fnol_data: FNOLClaimRequest) -> str:
        """Format location information for prompt"""
        if not fnol_data.incidentDetails.incidentLocation:
            return "Location not specified"
        
        loc = fnol_data.incidentDetails.incidentLocation
        parts = []
        if loc.description:
            parts.append(loc.description)
        if loc.city:
            parts.append(loc.city)
        if loc.state:
            parts.append(loc.state)
        if loc.country:
            parts.append(loc.country)
        
        return ", ".join(parts) if parts else "Location not specified"
    
    def _fallback_estimation(self, fnol_data: FNOLClaimRequest) -> Dict[str, Any]:
        """Provide rule-based fallback estimate if GPT-4o fails"""
        
        # Simple rule-based estimation
        base_costs = {
            "US": {
                "MINOR": 5000,
                "MODERATE": 15000,
                "SEVERE": 50000,
                "TOTAL_LOSS": 100000
            },
            "UK": {
                "MINOR": 3000,
                "MODERATE": 10000,
                "SEVERE": 30000,
                "TOTAL_LOSS": 60000
            }
        }
        
        # Determine severity from available data
        severity = "MODERATE"  # Default
        if fnol_data.immediateActions and fnol_data.immediateActions.vehicleDetails:
            damage = fnol_data.immediateActions.vehicleDetails.estimatedDamage
            if damage == "MINOR":
                severity = "MINOR"
            elif damage == "SEVERE":
                severity = "SEVERE"
            elif damage == "TOTAL_LOSS":
                severity = "TOTAL_LOSS"
        
        currency = "USD" if fnol_data.jurisdiction == "US" else "GBP"
        base_amount = base_costs[fnol_data.jurisdiction][severity]
        
        return {
            "estimated_total_cost": {
                "amount": base_amount,
                "currency": currency,
                "range": {
                    "min": base_amount * 0.7,
                    "max": base_amount * 1.5
                }
            },
            "severity_assessment": severity,
            "confidence_score": 0.5,
            "estimated_settlement_time": "30-60 days",
            "next_steps": [
                "Request medical documentation",
                "Obtain vehicle damage assessment",
                "Verify policy coverage"
            ],
            "meta": {
                "estimation_method": "FALLBACK_RULE_BASED",
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    
    async def enrich_claim_data(
        self,
        fnol_data: FNOLClaimRequest,
        estimation: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Use GPT-4o to suggest additional data to collect
        """
        
        prompt = f"""Based on this FNOL claim and initial estimation:

Claim Type: {fnol_data.claimType}
Severity: {estimation.get('severity_assessment')}
Estimated Cost: {estimation.get('estimated_total_cost', {}).get('amount')}

Current Information Available:
{json.dumps(fnol_data.dict(), indent=2, default=str)}

What additional information should we collect to improve claim accuracy?
Provide a prioritized list of missing data points that would significantly impact the estimate.

Respond in JSON format:
{{
  "critical_missing_data": ["<array>"],
  "recommended_documentation": ["<array>"],
  "suggested_questions": ["<array>"],
  "specialist_review_needed": "<boolean>",
  "priority_level": "<HIGH|MEDIUM|LOW>"
}}
"""
        
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a claims data analyst identifying missing information."
                    },
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1000,
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            logger.error("data_enrichment_failed", error=str(e))
            return {
                "critical_missing_data": [],
                "priority_level": "LOW"
            }
