"""
OCR Service for Claims Document Processing
Uses Azure Form Recognizer for intelligent document extraction
"""
import asyncio
from typing import Dict, Any, Optional, List
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.storage.blob import BlobServiceClient
import structlog
from uuid import uuid4
from datetime import datetime
import json

from app.core.config import settings
from app.models.schemas import DocumentType, Jurisdiction, ClaimType

logger = structlog.get_logger(__name__)


class OCRService:
    """Handles OCR extraction from claim documents"""
    
    def __init__(self):
        self.form_recognizer_client = DocumentAnalysisClient(
            endpoint=settings.AZURE_FORM_RECOGNIZER_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_FORM_RECOGNIZER_KEY)
        )
        self.blob_service_client = BlobServiceClient.from_connection_string(
            settings.AZURE_STORAGE_CONNECTION_STRING
        )
        self.container_client = self.blob_service_client.get_container_client(
            settings.AZURE_STORAGE_CONTAINER_NAME
        )
        
        # Field mappings for different form types
        self.field_mappings = self._load_field_mappings()
    
    def _load_field_mappings(self) -> Dict[str, Dict[str, str]]:
        """Define field mappings for different insurance forms"""
        return {
            "allstate_accident": {
                "policy_number": ["Policy Number", "Policy No", "Policy #"],
                "claimant_name": ["Policyholder Name", "Name", "Claimant"],
                "date_of_birth": ["Date of Birth", "DOB", "Birth Date"],
                "ssn": ["Social Security Number", "SSN", "SS#"],
                "incident_date": ["Date of Accident", "Accident Date", "DATE OF ACCIDENT"],
                "incident_description": ["Tell us exactly how", "accident/injury happened"],
                "diagnosis": ["Diagnosis", "ICD Code"],
                "employer": ["Employer Name"],
                "occupation": ["Occupation"]
            },
            "uk_claim_form": {
                "policy_number": ["Policy Number", "Policy Reference"],
                "ni_number": ["National Insurance Number", "NI Number"],
                "incident_date": ["Date of Incident", "Incident Date"],
                "gp_name": ["GP Name", "General Practitioner"],
                "nhs_number": ["NHS Number"]
            }
        }
    
    async def upload_document(
        self, 
        file_content: bytes, 
        filename: str,
        claim_id: str
    ) -> str:
        """Upload document to Azure Blob Storage"""
        try:
            blob_name = f"{claim_id}/{uuid4()}_{filename}"
            blob_client = self.container_client.get_blob_client(blob_name)
            
            blob_client.upload_blob(file_content, overwrite=True)
            
            logger.info(
                "document_uploaded",
                blob_name=blob_name,
                size=len(file_content)
            )
            
            return blob_client.url
            
        except Exception as e:
            logger.error("document_upload_failed", error=str(e))
            raise
    
    async def extract_from_document(
        self,
        document_url: str,
        document_type: DocumentType,
        jurisdiction: Jurisdiction
    ) -> Dict[str, Any]:
        """
        Extract structured data from document using Azure Form Recognizer
        """
        try:
            logger.info(
                "ocr_extraction_started",
                document_type=document_type,
                jurisdiction=jurisdiction
            )
            
            # Use appropriate model based on document type
            model_id = self._get_model_id(document_type, jurisdiction)
            
            poller = self.form_recognizer_client.begin_analyze_document_from_url(
                model_id=model_id,
                document_url=document_url
            )
            
            result = poller.result()
            
            # Extract fields based on document type
            extracted_data = self._parse_form_recognizer_result(
                result, 
                document_type,
                jurisdiction
            )
            
            # Calculate confidence score
            confidence = self._calculate_confidence(extracted_data)
            
            logger.info(
                "ocr_extraction_completed",
                fields_extracted=len(extracted_data.get('fields', {})),
                confidence=confidence
            )
            
            return {
                "confidence": confidence,
                "fields": extracted_data,
                "requires_validation": self._identify_low_confidence_fields(extracted_data)
            }
            
        except Exception as e:
            logger.error("ocr_extraction_failed", error=str(e))
            raise
    
    def _get_model_id(self, document_type: DocumentType, jurisdiction: Jurisdiction) -> str:
        """Select appropriate Form Recognizer model"""
        
        # Map to pre-trained or custom models
        model_map = {
            ("CLAIM_FORM", "US"): "prebuilt-document",  # Use custom model in production
            ("CLAIM_FORM", "UK"): "prebuilt-document",
            ("MEDICAL_BILL", "US"): "prebuilt-invoice",
            ("MEDICAL_BILL", "UK"): "prebuilt-invoice",
            ("PHYSICIAN_STATEMENT", "US"): "prebuilt-document",
            ("PHYSICIAN_STATEMENT", "UK"): "prebuilt-document"
        }
        
        return model_map.get((document_type, jurisdiction), "prebuilt-document")
    
    def _parse_form_recognizer_result(
        self,
        result: Any,
        document_type: DocumentType,
        jurisdiction: Jurisdiction
    ) -> Dict[str, Any]:
        """Parse Form Recognizer results into structured claim data"""
        
        extracted = {
            "fields": {},
            "tables": [],
            "key_value_pairs": []
        }
        
        # Extract key-value pairs
        for kv_pair in result.key_value_pairs:
            if kv_pair.key and kv_pair.value:
                key = kv_pair.key.content.strip()
                value = kv_pair.value.content.strip()
                confidence = (kv_pair.key.confidence + kv_pair.value.confidence) / 2
                
                extracted["fields"][key] = {
                    "value": value,
                    "confidence": confidence
                }
        
        # Extract tables (useful for itemized bills)
        for table in result.tables:
            table_data = []
            for cell in table.cells:
                table_data.append({
                    "row": cell.row_index,
                    "column": cell.column_index,
                    "content": cell.content,
                    "confidence": cell.confidence
                })
            extracted["tables"].append(table_data)
        
        # Map extracted fields to standard schema
        mapped_fields = self._map_to_schema(
            extracted["fields"],
            document_type,
            jurisdiction
        )
        
        return mapped_fields
    
    def _map_to_schema(
        self,
        raw_fields: Dict[str, Any],
        document_type: DocumentType,
        jurisdiction: Jurisdiction
    ) -> Dict[str, Any]:
        """Map extracted fields to standardized claim schema"""
        
        mapped = {}
        
        # Get appropriate field mappings
        form_type = f"{'uk' if jurisdiction == 'UK' else 'allstate'}_{'accident' if document_type == 'CLAIM_FORM' else 'claim'}"
        mappings = self.field_mappings.get(form_type, {})
        
        for standard_field, possible_labels in mappings.items():
            for label in possible_labels:
                if label in raw_fields:
                    mapped[standard_field] = raw_fields[label]
                    break
        
        # Post-process fields (format dates, parse amounts, etc.)
        mapped = self._post_process_fields(mapped)
        
        return mapped
    
    def _post_process_fields(self, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Clean and format extracted fields"""
        
        processed = {}
        
        for key, value_dict in fields.items():
            value = value_dict.get("value", "")
            confidence = value_dict.get("confidence", 0)
            
            # Date formatting
            if "date" in key.lower():
                processed[key] = {
                    "value": self._parse_date(value),
                    "confidence": confidence
                }
            
            # Amount parsing
            elif "amount" in key.lower() or "earnings" in key.lower():
                processed[key] = {
                    "value": self._parse_amount(value),
                    "confidence": confidence
                }
            
            # SSN/NI Number masking
            elif "ssn" in key.lower() or "ni_number" in key.lower():
                processed[key] = {
                    "value": self._mask_identifier(value),
                    "confidence": confidence
                }
            
            else:
                processed[key] = value_dict
        
        return processed
    
    def _parse_date(self, date_str: str) -> Optional[str]:
        """Parse various date formats to ISO format"""
        from dateutil import parser
        try:
            parsed = parser.parse(date_str, fuzzy=True)
            return parsed.date().isoformat()
        except:
            return None
    
    def _parse_amount(self, amount_str: str) -> Optional[float]:
        """Parse currency amounts"""
        import re
        try:
            # Remove currency symbols and commas
            cleaned = re.sub(r'[£$,]', '', amount_str)
            return float(cleaned)
        except:
            return None
    
    def _mask_identifier(self, identifier: str) -> str:
        """Mask SSN/NI numbers for security"""
        if len(identifier) > 4:
            return "X" * (len(identifier) - 4) + identifier[-4:]
        return identifier
    
    def _calculate_confidence(self, extracted_data: Dict[str, Any]) -> float:
        """Calculate overall confidence score"""
        
        confidences = [
            field.get("confidence", 0) 
            for field in extracted_data.get("fields", {}).values()
            if isinstance(field, dict)
        ]
        
        if not confidences:
            return 0.0
        
        return sum(confidences) / len(confidences)
    
    def _identify_low_confidence_fields(
        self,
        extracted_data: Dict[str, Any]
    ) -> List[str]:
        """Identify fields requiring manual validation"""
        
        low_confidence = []
        
        for field_name, field_data in extracted_data.get("fields", {}).items():
            if isinstance(field_data, dict):
                confidence = field_data.get("confidence", 0)
                if confidence < settings.OCR_CONFIDENCE_THRESHOLD:
                    low_confidence.append(field_name)
        
        return low_confidence
    
    async def generate_claim_preview(
        self,
        extracted_data: Dict[str, Any],
        document_type: DocumentType,
        jurisdiction: Jurisdiction
    ) -> Dict[str, Any]:
        """
        Generate pre-filled claim object from extracted data
        """
        
        # Build claim structure based on extracted fields
        claim_preview = {
            "claimType": self._infer_claim_type(extracted_data),
            "jurisdiction": jurisdiction,
            "policyHolder": self._build_policyholder(extracted_data),
            "incidentDetails": self._build_incident_details(extracted_data),
            "medicalInformation": self._build_medical_info(extracted_data),
            "financialInformation": self._build_financial_info(extracted_data)
        }
        
        return claim_preview
    
    def _infer_claim_type(self, extracted_data: Dict[str, Any]) -> str:
        """Infer claim type from extracted data"""
        
        fields = extracted_data.get("fields", {})
        
        # Simple inference logic (enhance with ML in production)
        if any("accident" in str(v).lower() for v in fields.values()):
            return ClaimType.ACCIDENT
        elif any("disability" in str(v).lower() for v in fields.values()):
            return ClaimType.DISABILITY
        elif any("pregnancy" in str(v).lower() for v in fields.values()):
            return ClaimType.ROUTINE_PREGNANCY
        
        return ClaimType.ACCIDENT  # Default
    
    def _build_policyholder(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build policyholder object from extracted data"""
        
        fields = extracted_data.get("fields", {})
        
        # Extract name components
        full_name = fields.get("claimant_name", {}).get("value", "")
        name_parts = full_name.split()
        
        return {
            "policyNumber": fields.get("policy_number", {}).get("value"),
            "firstName": name_parts[0] if len(name_parts) > 0 else None,
            "lastName": name_parts[-1] if len(name_parts) > 1 else None,
            "dateOfBirth": fields.get("date_of_birth", {}).get("value"),
            # ... additional fields
        }
    
    def _build_incident_details(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build incident details from extracted data"""
        
        fields = extracted_data.get("fields", {})
        
        return {
            "incidentDate": fields.get("incident_date", {}).get("value"),
            "incidentDescription": fields.get("incident_description", {}).get("value"),
            # ... additional fields
        }
    
    def _build_medical_info(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build medical information from extracted data"""
        
        fields = extracted_data.get("fields", {})
        
        return {
            "diagnosis": [
                {
                    "code": fields.get("diagnosis", {}).get("value"),
                    "description": ""
                }
            ] if fields.get("diagnosis") else []
        }
    
    def _build_financial_info(self, extracted_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build financial information from extracted data"""
        
        # Extract from tables if present (itemized bills)
        tables = extracted_data.get("tables", [])
        
        itemized_bills = []
        # Parse table data to extract bills
        # ... implementation
        
        return {
            "itemizedBills": itemized_bills
        }
