"""
Security Module - OAuth 2.0 Implementation
JWT token validation and scope-based authorization
"""
from fastapi import Depends, HTTPException, status, Security
from fastapi.security import OAuth2AuthorizationCodeBearer, SecurityScopes
from jose import JWTError, jwt
from pydantic import ValidationError
from typing import Optional
from datetime import datetime, timedelta
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)

# OAuth2 scheme
oauth2_scheme = OAuth2AuthorizationCodeBearer(
    authorizationUrl=f"{settings.OAUTH_TOKEN_URL}/authorize",
    tokenUrl=settings.OAUTH_TOKEN_URL,
    scopes={
        "claims:read": "Read claim information",
        "claims:write": "Submit and modify claims",
        "claims:admin": "Administrative access to all claims"
    }
)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create JWT access token"""
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM
    )
    
    return encoded_jwt


def create_refresh_token(data: dict) -> str:
    """Create JWT refresh token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM
    )
    
    return encoded_jwt


async def get_current_user(
    security_scopes: SecurityScopes,
    token: str = Depends(oauth2_scheme)
) -> dict:
    """
    Validate JWT token and extract user information
    Implements OAuth 2.0 token validation
    """
    
    if security_scopes.scopes:
        authenticate_value = f'Bearer scope="{security_scopes.scope_str}"'
    else:
        authenticate_value = "Bearer"
    
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": authenticate_value},
    )
    
    try:
        # Decode JWT token
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )
        
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
        
        token_scopes = payload.get("scopes", [])
        token_data = {
            "sub": user_id,
            "scopes": token_scopes,
            "client_id": payload.get("client_id"),
            "exp": payload.get("exp")
        }
        
    except (JWTError, ValidationError) as e:
        logger.error("token_validation_failed", error=str(e))
        raise credentials_exception
    
    # Verify required scopes
    for scope in security_scopes.scopes:
        if scope not in token_scopes:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions",
                headers={"WWW-Authenticate": authenticate_value},
            )
    
    # Optionally verify user still exists in database
    # user = await get_user_by_id(user_id)
    # if not user or not user.is_active:
    #     raise credentials_exception
    
    logger.info(
        "user_authenticated",
        user_id=user_id,
        scopes=token_scopes,
        client_id=token_data.get("client_id")
    )
    
    return token_data


def require_scope(scope: str):
    """
    Dependency to require specific scope
    Usage: _: None = Depends(require_scope("claims:write"))
    """
    async def scope_checker(token: str = Depends(oauth2_scheme)) -> None:
        try:
            payload = jwt.decode(
                token,
                settings.SECRET_KEY,
                algorithms=[settings.ALGORITHM]
            )
            token_scopes = payload.get("scopes", [])
            
            if scope not in token_scopes:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Missing required scope: {scope}",
                    headers={"WWW-Authenticate": f'Bearer scope="{scope}"'}
                )
        except JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"}
            )
    
    return scope_checker


# API Key Authentication (for service-to-service)
async def verify_api_key(api_key: str) -> dict:
    """Verify API key for service-to-service authentication"""
    
    # In production, validate against database or key vault
    # For now, simple validation
    
    if not api_key or api_key != settings.MENDIX_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key"
        )
    
    return {
        "client_id": "mendix_service",
        "scopes": ["claims:read", "claims:write"]
    }


# Role-based access control
class RoleChecker:
    """Check if user has required role"""
    
    def __init__(self, required_roles: list[str]):
        self.required_roles = required_roles
    
    async def __call__(self, current_user: dict = Depends(get_current_user)):
        user_roles = current_user.get("roles", [])
        
        if not any(role in user_roles for role in self.required_roles):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions"
            )
        
        return current_user


# Commonly used role checkers
require_admin = RoleChecker(["admin"])
require_adjuster = RoleChecker(["admin", "adjuster"])
require_reviewer = RoleChecker(["admin", "adjuster", "reviewer"])


# Encryption utilities for PII
from cryptography.fernet import Fernet
import base64

class PIIEncryption:
    """Handle encryption of PII fields"""
    
    def __init__(self):
        # In production, load from Azure Key Vault
        self.key = base64.urlsafe_b64encode(settings.SECRET_KEY.encode()[:32])
        self.cipher = Fernet(self.key)
    
    def encrypt(self, data: str) -> str:
        """Encrypt sensitive data"""
        return self.cipher.encrypt(data.encode()).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt sensitive data"""
        return self.cipher.decrypt(encrypted_data.encode()).decode()
    
    def mask(self, data: str, show_last: int = 4) -> str:
        """Mask sensitive data for display"""
        if len(data) <= show_last:
            return "*" * len(data)
        return "*" * (len(data) - show_last) + data[-show_last:]


pii_encryption = PIIEncryption()
