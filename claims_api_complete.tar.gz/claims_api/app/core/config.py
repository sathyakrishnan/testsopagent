"""
Configuration management for Claims Processing API
Supports multiple environments: development, staging, production
"""
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, validator
import os


class Settings(BaseSettings):
    """Application settings with environment-specific configurations"""
    
    # Application
    APP_NAME: str = "XYZ Claims Processing API"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = Field(default="development", env="ENVIRONMENT")
    DEBUG: bool = Field(default=False, env="DEBUG")
    
    # API Configuration
    API_V1_PREFIX: str = "/api/v1"
    API_HOST: str = Field(default="0.0.0.0", env="API_HOST")
    API_PORT: int = Field(default=8000, env="API_PORT")
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "https://mendix.xyzconsulting.com"],
        env="CORS_ORIGINS"
    )
    
    # Security
    SECRET_KEY: str = Field(..., env="SECRET_KEY")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    API_KEY_HEADER: str = "X-API-Key"
    
    # OAuth 2.0
    OAUTH_TOKEN_URL: str = Field(..., env="OAUTH_TOKEN_URL")
    OAUTH_CLIENT_ID: str = Field(..., env="OAUTH_CLIENT_ID")
    OAUTH_CLIENT_SECRET: str = Field(..., env="OAUTH_CLIENT_SECRET")
    
    # Database
    DATABASE_URL: str = Field(..., env="DATABASE_URL")
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 40
    DB_POOL_TIMEOUT: int = 30
    DB_POOL_RECYCLE: int = 3600
    
    # Azure Configuration
    AZURE_STORAGE_CONNECTION_STRING: str = Field(..., env="AZURE_STORAGE_CONNECTION_STRING")
    AZURE_STORAGE_CONTAINER_NAME: str = Field(default="claims-documents", env="AZURE_STORAGE_CONTAINER")
    AZURE_KEYVAULT_URL: str = Field(..., env="AZURE_KEYVAULT_URL")
    AZURE_FORM_RECOGNIZER_ENDPOINT: str = Field(..., env="AZURE_FORM_RECOGNIZER_ENDPOINT")
    AZURE_FORM_RECOGNIZER_KEY: str = Field(..., env="AZURE_FORM_RECOGNIZER_KEY")
    AZURE_APP_INSIGHTS_KEY: str = Field(..., env="AZURE_APP_INSIGHTS_KEY")
    
    # Redis Cache
    REDIS_URL: str = Field(default="redis://localhost:6379/0", env="REDIS_URL")
    CACHE_TTL: int = 3600  # 1 hour
    
    # Celery
    CELERY_BROKER_URL: str = Field(default="redis://localhost:6379/1", env="CELERY_BROKER_URL")
    CELERY_RESULT_BACKEND: str = Field(default="redis://localhost:6379/2", env="CELERY_RESULT_BACKEND")
    
    # AI Configuration
    ANTHROPIC_API_KEY: str = Field(..., env="ANTHROPIC_API_KEY")
    ANTHROPIC_MODEL: str = Field(default="claude-sonnet-4-20250514", env="ANTHROPIC_MODEL")
    OPENAI_API_KEY: str = Field(..., env="OPENAI_API_KEY")
    OPENAI_MODEL: str = Field(default="gpt-4o", env="OPENAI_MODEL")
    
    # Rate Limiting
    RATE_LIMIT_TEXT_CLAIMS: int = 100  # per minute
    RATE_LIMIT_OCR_CLAIMS: int = 20    # per minute
    RATE_LIMIT_STATUS: int = 500        # per minute
    
    # File Upload
    MAX_FILE_SIZE: int = 10 * 1024 * 1024  # 10MB
    ALLOWED_EXTENSIONS: List[str] = [".pdf", ".jpg", ".jpeg", ".png", ".tiff"]
    
    # Processing
    OCR_CONFIDENCE_THRESHOLD: float = 0.75
    FRAUD_DETECTION_THRESHOLD: float = 0.65
    AUTO_APPROVE_THRESHOLD: float = 0.95
    
    # Monitoring
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090
    LOG_LEVEL: str = Field(default="INFO", env="LOG_LEVEL")
    
    # Compliance
    HIPAA_AUDIT_ENABLED: bool = True
    GDPR_COMPLIANCE_ENABLED: bool = True
    DATA_RETENTION_DAYS: int = 2555  # 7 years
    
    # External Integrations
    MENDIX_WEBHOOK_URL: Optional[str] = Field(default=None, env="MENDIX_WEBHOOK_URL")
    MENDIX_API_KEY: Optional[str] = Field(default=None, env="MENDIX_API_KEY")
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True
    )
    
    @validator("ENVIRONMENT")
    def validate_environment(cls, v):
        allowed = ["development", "staging", "production"]
        if v not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {allowed}")
        return v
    
    @validator("LOG_LEVEL")
    def validate_log_level(cls, v):
        allowed = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {allowed}")
        return v.upper()
    
    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"
    
    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT == "development"


# Singleton settings instance
settings = Settings()
