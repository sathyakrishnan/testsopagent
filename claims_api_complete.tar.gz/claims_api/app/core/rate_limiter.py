"""
Rate Limiting Implementation
Token bucket algorithm with Redis backend
"""
import time
from typing import Callable
from fastapi import Request, HTTPException, status
from functools import wraps
import structlog

logger = structlog.get_logger(__name__)


class RateLimiter:
    """Simple in-memory rate limiter (use Redis in production)"""
    
    def __init__(self):
        self.requests = {}  # {client_id: [(timestamp, count), ...]}
    
    def _get_client_id(self, request: Request) -> str:
        """Extract client identifier from request"""
        # Try to get user from token
        if hasattr(request.state, "user"):
            return request.state.user.get("sub", "anonymous")
        
        # Fall back to IP address
        return request.client.host if request.client else "unknown"
    
    def _clean_old_requests(self, client_id: str, window: int):
        """Remove requests outside the time window"""
        current_time = time.time()
        if client_id in self.requests:
            self.requests[client_id] = [
                (ts, count) for ts, count in self.requests[client_id]
                if current_time - ts < window
            ]
    
    def limit(self, limit_string: str):
        """
        Rate limit decorator
        Format: "100/minute" or "20/hour"
        """
        # Parse limit string
        count, period = limit_string.split("/")
        count = int(count)
        
        window_seconds = {
            "second": 1,
            "minute": 60,
            "hour": 3600,
            "day": 86400
        }[period]
        
        def decorator(func: Callable):
            @wraps(func)
            async def wrapper(*args, **kwargs):
                # Extract request from args/kwargs
                request = None
                for arg in args:
                    if isinstance(arg, Request):
                        request = arg
                        break
                
                if not request:
                    for value in kwargs.values():
                        if isinstance(value, Request):
                            request = value
                            break
                
                if request:
                    client_id = self._get_client_id(request)
                    
                    # Clean old requests
                    self._clean_old_requests(client_id, window_seconds)
                    
                    # Check rate limit
                    current_time = time.time()
                    if client_id not in self.requests:
                        self.requests[client_id] = []
                    
                    # Count requests in window
                    request_count = sum(c for _, c in self.requests[client_id])
                    
                    if request_count >= count:
                        logger.warning(
                            "rate_limit_exceeded",
                            client_id=client_id,
                            limit=limit_string
                        )
                        raise HTTPException(
                            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                            detail=f"Rate limit exceeded: {limit_string}",
                            headers={
                                "X-RateLimit-Limit": str(count),
                                "X-RateLimit-Remaining": "0",
                                "X-RateLimit-Reset": str(int(current_time + window_seconds))
                            }
                        )
                    
                    # Add request
                    self.requests[client_id].append((current_time, 1))
                
                return await func(*args, **kwargs)
            
            return wrapper
        return decorator


# Global rate limiter instance
limiter = RateLimiter()
