"""
FNOL-specific Pydantic Models
Based on realistic First Notice of Loss data capture
"""
from typing import Optional, List
from datetime import datetime, date
from enum import Enum
from pydantic import BaseModel, Field, validator, EmailStr
from uuid import UUID, uuid4


# Enumerations
class ClaimTypeEnum(str, Enum):
    ACCIDENT = "ACCIDENT"
    DISABILITY = "DISABILITY"
    DEATH_CLAIM = "DEATH_CLAIM"
    HOSPITAL_ADMISSION = "HOSPITAL_ADMISSION"
    INJURY = "INJURY"


class JurisdictionEnum(str, Enum):
    US = "US"
    UK = "UK"


class IncidentTypeEnum(str, Enum):
    MOTOR_VEHICLE_ACCIDENT = "MOTOR_VEHICLE_ACCIDENT"
    SLIP_AND_FALL = "SLIP_AND_FALL"
    WORKPLACE_INJURY = "WORKPLACE_INJURY"
    HOME_ACCIDENT = "HOME_ACCIDENT"
    SPORTS_INJURY = "SPORTS_INJURY"
    ASSAULT = "ASSAULT"
    ILLNESS_SUDDEN = "ILLNESS_SUDDEN"
    OTHER = "OTHER"


class DamageLevelEnum(str, Enum):
    MINOR = "MINOR"
    MODERATE = "MODERATE"
    SEVERE = "SEVERE"
    TOTAL_LOSS = "TOTAL_LOSS"


class ChannelEnum(str, Enum):
    MENDIX_PORTAL = "MENDIX_PORTAL"
    MOBILE_APP = "MOBILE_APP"
    CALL_CENTER = "CALL_CENTER"
    CHATBOT = "CHATBOT"
    EMAIL = "EMAIL"


class UrgencyLevelEnum(str, Enum):
    CRITICAL = "CRITICAL"
    URGENT = "URGENT"
    NORMAL = "NORMAL"


# Nested Models
class Locale(BaseModel):
    country: str
    state: Optional[str] = None


class ContactInformation(BaseModel):
    primaryPhone: str = Field(..., description="Essential for follow-up")
    alternatePhone: Optional[str] = None
    email: Optional[EmailStr] = None
    preferredContactMethod: Optional[str] = Field(default="PHONE", pattern="^(PHONE|EMAIL|SMS)$")
    bestTimeToCall: Optional[str] = None


class CurrentLocation(BaseModel):
    description: Optional[str] = None
    address: Optional[dict] = None


class PolicyHolder(BaseModel):
    policyNumber: str
    firstName: str
    middleName: Optional[str] = None
    lastName: str
    dateOfBirth: Optional[date] = None
    contactInformation: ContactInformation
    currentLocation: Optional[CurrentLocation] = None


class IncidentLocation(BaseModel):
    description: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None


class EmergencyServices(BaseModel):
    policeNotified: Optional[bool] = None
    policeReportNumber: Optional[str] = None
    ambulanceCalled: Optional[bool] = None
    fireServiceInvolved: Optional[bool] = None


class IncidentDetails(BaseModel):
    incidentDate: datetime
    incidentType: IncidentTypeEnum
    incidentLocation: Optional[IncidentLocation] = None
    incidentDescription: str = Field(..., max_length=500)
    injuriesReported: Optional[List[str]] = None
    emergencyServicesInvolved: Optional[EmergencyServices] = None
    witnessesPresent: Optional[bool] = None
    workRelated: bool = False


class CurrentMedicalCare(BaseModel):
    receivingTreatment: Optional[bool] = None
    location: Optional[str] = None
    admittedToHospital: Optional[bool] = None


class VehicleDetails(BaseModel):
    vehicleDriveable: Optional[bool] = None
    currentVehicleLocation: Optional[str] = None
    estimatedDamage: Optional[DamageLevelEnum] = None


class ImmediateAssistance(BaseModel):
    needsTowTruck: Optional[bool] = None
    needsRentalCar: Optional[bool] = None
    needsTransportation: Optional[bool] = None
    needsInterpreter: Optional[bool] = None
    language: Optional[str] = None


class ImmediateActions(BaseModel):
    currentMedicalCare: Optional[CurrentMedicalCare] = None
    ableToWork: Optional[bool] = None
    vehicleDetails: Optional[VehicleDetails] = None
    requiresImmediateAssistance: Optional[ImmediateAssistance] = None


class ThirdPartyDetails(BaseModel):
    name: Optional[str] = None
    contactPhone: Optional[str] = None
    insuranceCompany: Optional[str] = None
    policyNumber: Optional[str] = None
    vehicleRegistration: Optional[str] = None


class ThirdPartyInformation(BaseModel):
    thirdPartyInvolved: Optional[bool] = None
    thirdPartyDetails: Optional[ThirdPartyDetails] = None


class SubmissionMetadata(BaseModel):
    submittedBy: str
    reporterRelationship: Optional[str] = Field(default="SELF", pattern="^(SELF|FAMILY_MEMBER|EMPLOYER|MEDICAL_PROVIDER|ATTORNEY|OTHER)$")
    submissionTimestamp: datetime
    channel: ChannelEnum
    correlationId: UUID = Field(default_factory=uuid4)
    callbackRequired: Optional[bool] = False
    urgencyLevel: Optional[UrgencyLevelEnum] = UrgencyLevelEnum.NORMAL


class ConsentAndAuthorizations(BaseModel):
    medicalRecordsRelease: Optional[bool] = None
    dataProcessingConsent: Optional[bool] = None
    thirdPartyContactAuthorization: Optional[bool] = None
    consentTimestamp: Optional[datetime] = None


# Main Request Model
class FNOLClaimRequest(BaseModel):
    claimType: ClaimTypeEnum
    jurisdiction: JurisdictionEnum
    locale: Optional[Locale] = None
    policyHolder: PolicyHolder
    incidentDetails: IncidentDetails
    immediateActions: Optional[ImmediateActions] = None
    thirdPartyInformation: Optional[ThirdPartyInformation] = None
    submissionMetadata: SubmissionMetadata
    consentAndAuthorizations: Optional[ConsentAndAuthorizations] = None


# Estimation Response Models
class EstimatedCost(BaseModel):
    amount: float
    currency: str = Field(..., pattern="^(USD|GBP)$")
    range: dict = Field(..., description="Min and max estimates")


class CostBreakdown(BaseModel):
    medical_expenses: float = 0
    property_damage: float = 0
    lost_wages: float = 0
    other_costs: float = 0


class RecommendedReserve(BaseModel):
    amount: float
    justification: str


class ClaimEstimationResponse(BaseModel):
    estimated_total_cost: EstimatedCost
    cost_breakdown: CostBreakdown
    severity_assessment: str = Field(..., pattern="^(MINOR|MODERATE|SEVERE|CATASTROPHIC)$")
    confidence_score: float = Field(..., ge=0, le=1)
    estimated_settlement_time: str
    recommended_reserve: RecommendedReserve
    risk_factors: List[str]
    red_flags: List[str]
    next_steps: List[str]
    similar_claims_analysis: str
    special_considerations: List[str]
    meta: Optional[dict] = None


# Combined FNOL + Estimation Response
class FNOLSubmissionResponse(BaseModel):
    claimId: UUID
    claimNumber: str
    status: str = Field(..., pattern="^(RECEIVED|PROCESSING|UNDER_REVIEW|APPROVED|DENIED)$")
    submissionTimestamp: datetime
    fnolData: dict
    estimation: ClaimEstimationResponse
    dataCompleteness: dict
    nextSteps: List[str]
    estimatedProcessingTime: str = "3-5 business days"


# Additional Data Recommendations
class DataEnrichmentResponse(BaseModel):
    critical_missing_data: List[str]
    recommended_documentation: List[str]
    suggested_questions: List[str]
    specialist_review_needed: bool
    priority_level: str = Field(..., pattern="^(HIGH|MEDIUM|LOW)$")
