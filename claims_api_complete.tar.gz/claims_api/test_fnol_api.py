#!/usr/bin/env python3
"""
FNOL API Test Script
Tests complete FNOL submission and estimation flow
"""
import requests
import json
from datetime import datetime
from uuid import uuid4

# Configuration
API_BASE_URL = "http://localhost:8000/api/v1"
# For Azure: API_BASE_URL = "https://xyz-claims-api-production.azurewebsites.net/api/v1"

def get_auth_token():
    """Get OAuth token"""
    response = requests.post(
        f"{API_BASE_URL}/auth/token",
        data={
            "username": "mendix_client",
            "password": "secret",
            "scope": "claims:read claims:write"
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"}
    )
    response.raise_for_status()
    return response.json()["access_token"]


def test_us_accident_fnol():
    """Test US motor vehicle accident FNOL"""
    
    print("\n" + "="*60)
    print("TEST 1: US Motor Vehicle Accident FNOL")
    print("="*60)
    
    # Get token
    token = get_auth_token()
    print("✓ Authentication successful")
    
    # Prepare FNOL data
    fnol_data = {
        "claimType": "ACCIDENT",
        "jurisdiction": "US",
        "locale": {
            "country": "US",
            "state": "FL"
        },
        "policyHolder": {
            "policyNumber": "POL-US-2024-123456",
            "firstName": "John",
            "lastName": "Smith",
            "contactInformation": {
                "primaryPhone": "+1-904-555-1234",
                "alternatePhone": "+1-904-555-5678",
                "email": "john.smith@email.com",
                "preferredContactMethod": "PHONE",
                "bestTimeToCall": "Anytime today - I'm at the hospital"
            },
            "currentLocation": {
                "description": "Memorial Hospital Emergency Room",
                "address": {
                    "city": "Jacksonville",
                    "state": "FL",
                    "postalCode": "32207"
                }
            }
        },
        "incidentDetails": {
            "incidentDate": "2024-11-15T14:30:00Z",
            "incidentType": "MOTOR_VEHICLE_ACCIDENT",
            "incidentLocation": {
                "description": "Intersection of I-95 and Beach Blvd",
                "city": "Jacksonville",
                "state": "FL",
                "country": "US"
            },
            "incidentDescription": "I was stopped at a red light and another car hit me from behind. My neck hurts and I have a headache.",
            "injuriesReported": [
                "Neck pain",
                "Headache",
                "Back soreness"
            ],
            "emergencyServicesInvolved": {
                "policeNotified": True,
                "policeReportNumber": "JPD-2024-11-15-4567",
                "ambulanceCalled": True,
                "fireServiceInvolved": False
            },
            "witnessesPresent": True,
            "workRelated": False
        },
        "immediateActions": {
            "currentMedicalCare": {
                "receivingTreatment": True,
                "location": "Memorial Hospital ER",
                "admittedToHospital": False
            },
            "ableToWork": False,
            "vehicleDetails": {
                "vehicleDriveable": False,
                "currentVehicleLocation": "Towed to Joe's Auto Body",
                "estimatedDamage": "MODERATE"
            },
            "requiresImmediateAssistance": {
                "needsTowTruck": False,
                "needsRentalCar": True,
                "needsTransportation": True,
                "needsInterpreter": False
            }
        },
        "thirdPartyInformation": {
            "thirdPartyInvolved": True,
            "thirdPartyDetails": {
                "name": "Jane Doe",
                "contactPhone": "+1-904-555-9999",
                "insuranceCompany": "State Farm",
                "policyNumber": "SF-789456123",
                "vehicleRegistration": "ABC-1234"
            }
        },
        "submissionMetadata": {
            "submittedBy": "John Smith",
            "reporterRelationship": "SELF",
            "submissionTimestamp": datetime.utcnow().isoformat() + "Z",
            "channel": "MOBILE_APP",
            "correlationId": str(uuid4()),
            "callbackRequired": True,
            "urgencyLevel": "URGENT"
        },
        "consentAndAuthorizations": {
            "medicalRecordsRelease": True,
            "dataProcessingConsent": True,
            "thirdPartyContactAuthorization": True,
            "consentTimestamp": datetime.utcnow().isoformat() + "Z"
        }
    }
    
    # Submit FNOL
    print("\nSubmitting FNOL to API...")
    response = requests.post(
        f"{API_BASE_URL}/claims/fnol",
        json=fnol_data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    )
    
    if response.status_code == 201:
        result = response.json()
        print("\n✓ FNOL submitted successfully!")
        print(f"\nClaim ID: {result['claimId']}")
        print(f"Claim Number: {result['claimNumber']}")
        print(f"Status: {result['status']}")
        
        print("\n--- AI ESTIMATION RESULTS ---")
        estimation = result['estimation']
        print(f"Estimated Total Cost: ${estimation['estimated_total_cost']['amount']:,.2f} {estimation['estimated_total_cost']['currency']}")
        print(f"Range: ${estimation['estimated_total_cost']['range']['min']:,.2f} - ${estimation['estimated_total_cost']['range']['max']:,.2f}")
        print(f"Severity: {estimation['severity_assessment']}")
        print(f"Confidence: {estimation['confidence_score']:.0%}")
        print(f"Settlement Time: {estimation['estimated_settlement_time']}")
        
        print("\n--- COST BREAKDOWN ---")
        breakdown = estimation['cost_breakdown']
        print(f"Medical Expenses: ${breakdown['medical_expenses']:,.2f}")
        print(f"Property Damage: ${breakdown['property_damage']:,.2f}")
        print(f"Lost Wages: ${breakdown['lost_wages']:,.2f}")
        print(f"Other Costs: ${breakdown['other_costs']:,.2f}")
        
        print("\n--- RISK FACTORS ---")
        for risk in estimation['risk_factors']:
            print(f"• {risk}")
        
        if estimation['red_flags']:
            print("\n--- RED FLAGS ---")
            for flag in estimation['red_flags']:
                print(f"⚠ {flag}")
        
        print("\n--- NEXT STEPS ---")
        for step in result['nextSteps']:
            print(f"→ {step}")
        
        print(f"\nEstimated Processing Time: {result['estimatedProcessingTime']}")
        
        return result
    else:
        print(f"\n✗ FNOL submission failed: {response.status_code}")
        print(response.text)
        return None


def test_uk_accident_fnol():
    """Test UK motor vehicle accident FNOL"""
    
    print("\n" + "="*60)
    print("TEST 2: UK Motor Vehicle Accident FNOL")
    print("="*60)
    
    token = get_auth_token()
    print("✓ Authentication successful")
    
    fnol_data = {
        "claimType": "ACCIDENT",
        "jurisdiction": "UK",
        "locale": {
            "country": "UK",
            "state": "Greater London"
        },
        "policyHolder": {
            "policyNumber": "POL-UK-2024-987654",
            "firstName": "Emma",
            "middleName": "Jane",
            "lastName": "Williams",
            "contactInformation": {
                "primaryPhone": "+44-7911-123456",
                "email": "emma.williams@email.co.uk",
                "preferredContactMethod": "PHONE"
            },
            "currentLocation": {
                "description": "St Thomas' Hospital A&E",
                "address": {
                    "city": "London",
                    "postalCode": "SE1 7EH"
                }
            }
        },
        "incidentDetails": {
            "incidentDate": "2024-11-15T09:15:00Z",
            "incidentType": "MOTOR_VEHICLE_ACCIDENT",
            "incidentLocation": {
                "description": "Roundabout at Westminster Bridge Road",
                "city": "London",
                "country": "UK"
            },
            "incidentDescription": "Another vehicle failed to give way at the roundabout and collided with my car. Pain in left shoulder and wrist.",
            "injuriesReported": [
                "Left shoulder pain",
                "Wrist pain"
            ],
            "emergencyServicesInvolved": {
                "policeNotified": True,
                "policeReportNumber": "MPS-2024-11-15-8901",
                "ambulanceCalled": True
            },
            "workRelated": False
        },
        "immediateActions": {
            "currentMedicalCare": {
                "receivingTreatment": True,
                "location": "St Thomas' Hospital A&E",
                "admittedToHospital": False
            },
            "ableToWork": False,
            "vehicleDetails": {
                "vehicleDriveable": False,
                "estimatedDamage": "SEVERE"
            }
        },
        "thirdPartyInformation": {
            "thirdPartyInvolved": True,
            "thirdPartyDetails": {
                "insuranceCompany": "Aviva",
                "vehicleRegistration": "BD15 XYZ"
            }
        },
        "submissionMetadata": {
            "submittedBy": "Emma Williams",
            "reporterRelationship": "SELF",
            "submissionTimestamp": datetime.utcnow().isoformat() + "Z",
            "channel": "CALL_CENTER",
            "urgencyLevel": "URGENT"
        }
    }
    
    print("\nSubmitting UK FNOL...")
    response = requests.post(
        f"{API_BASE_URL}/claims/fnol",
        json=fnol_data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    )
    
    if response.status_code == 201:
        result = response.json()
        print(f"\n✓ UK claim submitted: {result['claimNumber']}")
        print(f"Estimated Cost: £{result['estimation']['estimated_total_cost']['amount']:,.2f}")
        print(f"Severity: {result['estimation']['severity_assessment']}")
        return result
    else:
        print(f"\n✗ Submission failed: {response.status_code}")
        print(response.text)
        return None


def test_estimate_only():
    """Test estimation-only endpoint"""
    
    print("\n" + "="*60)
    print("TEST 3: Estimation Only (No Submission)")
    print("="*60)
    
    token = get_auth_token()
    
    fnol_data = {
        "claimType": "ACCIDENT",
        "jurisdiction": "US",
        "policyHolder": {
            "policyNumber": "POL-TEST-123",
            "firstName": "Test",
            "lastName": "User",
            "contactInformation": {
                "primaryPhone": "+1-555-000-0000"
            }
        },
        "incidentDetails": {
            "incidentDate": datetime.utcnow().isoformat() + "Z",
            "incidentType": "SLIP_AND_FALL",
            "incidentDescription": "Slipped on wet floor at grocery store",
            "injuriesReported": ["Twisted ankle", "Bruised elbow"]
        },
        "submissionMetadata": {
            "submittedBy": "Test User",
            "submissionTimestamp": datetime.utcnow().isoformat() + "Z",
            "channel": "WEB_PORTAL"
        }
    }
    
    print("\nGetting estimation without submission...")
    response = requests.post(
        f"{API_BASE_URL}/claims/fnol/estimate-only",
        json=fnol_data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    )
    
    if response.status_code == 200:
        estimation = response.json()
        print(f"\n✓ Estimation received")
        print(f"Estimated Cost: ${estimation['estimated_total_cost']['amount']:,.2f}")
        print(f"Severity: {estimation['severity_assessment']}")
        print(f"Confidence: {estimation['confidence_score']:.0%}")
        return estimation
    else:
        print(f"\n✗ Estimation failed: {response.status_code}")
        return None


def test_health_check():
    """Test API health"""
    print("\n" + "="*60)
    print("Testing API Health")
    print("="*60)
    
    response = requests.get(f"{API_BASE_URL.replace('/v1', '')}/health")
    if response.status_code == 200:
        print("✓ API is healthy")
        return True
    else:
        print("✗ API health check failed")
        return False


if __name__ == "__main__":
    print("\n" + "="*60)
    print("XYZ FNOL API - COMPREHENSIVE TEST SUITE")
    print("="*60)
    print(f"API Base URL: {API_BASE_URL}")
    print(f"Test Time: {datetime.utcnow().isoformat()}")
    
    try:
        # Health check
        if not test_health_check():
            print("\n⚠ API is not responding. Please start the server first.")
            exit(1)
        
        # Test 1: US Accident
        us_result = test_us_accident_fnol()
        
        # Test 2: UK Accident  
        uk_result = test_uk_accident_fnol()
        
        # Test 3: Estimation only
        estimate_result = test_estimate_only()
        
        print("\n" + "="*60)
        print("TEST SUMMARY")
        print("="*60)
        print(f"✓ US Accident FNOL: {'PASS' if us_result else 'FAIL'}")
        print(f"✓ UK Accident FNOL: {'PASS' if uk_result else 'FAIL'}")
        print(f"✓ Estimation Only: {'PASS' if estimate_result else 'FAIL'}")
        print("\nAll tests completed!")
        
    except Exception as e:
        print(f"\n✗ Test suite failed: {str(e)}")
        import traceback
        traceback.print_exc()
