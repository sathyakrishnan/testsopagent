"""
Test Suite for Claims Processing API
Comprehensive integration and unit tests
"""
import pytest
from fastapi.testclient import TestClient
from datetime import datetime, date
from uuid import uuid4
import json

from app.main import app
from app.core.security import create_access_token
from app.models.schemas import (
    ClaimType, Jurisdiction, Gender,
    TextBasedClaimRequest, ClaimResponse
)

client = TestClient(app)


# Fixtures
@pytest.fixture
def auth_headers():
    """Generate valid auth headers"""
    token = create_access_token(
        data={
            "sub": "test_user_123",
            "scopes": ["claims:read", "claims:write"],
            "client_id": "test_client"
        }
    )
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def sample_us_claim():
    """Sample US accident claim"""
    return {
        "claimType": "ACCIDENT",
        "jurisdiction": "US",
        "locale": {
            "country": "US",
            "state": "FL",
            "regulatoryZone": "FL_OIR"
        },
        "policyHolder": {
            "policyNumber": "POL-US-2024-123456",
            "firstName": "John",
            "lastName": "Smith",
            "dateOfBirth": "1985-06-15",
            "gender": "MALE",
            "nationalIdentifier": {
                "type": "SSN",
                "value": "XXX-XX-1234"
            },
            "contactInformation": {
                "primaryPhone": "+1-904-555-1234",
                "email": "john.smith@email.com",
                "preferredLanguage": "en-US"
            },
            "address": {
                "street1": "123 Main Street",
                "city": "Jacksonville",
                "stateProvince": "FL",
                "postalCode": "32203",
                "country": "US"
            }
        },
        "incidentDetails": {
            "incidentDate": "2024-11-15T14:30:00Z",
            "incidentType": "ACCIDENT",
            "incidentDescription": "Motor vehicle collision at intersection",
            "workRelated": False
        },
        "submissionMetadata": {
            "submittedBy": "test_user",
            "submissionTimestamp": datetime.utcnow().isoformat() + "Z",
            "channel": "MENDIX_PORTAL",
            "correlationId": str(uuid4())
        }
    }


@pytest.fixture
def sample_uk_claim():
    """Sample UK disability claim"""
    return {
        "claimType": "DISABILITY",
        "jurisdiction": "UK",
        "locale": {
            "country": "UK",
            "state": "England",
            "regulatoryZone": "FCA_UK_ZONE_1"
        },
        "policyHolder": {
            "policyNumber": "POL-UK-2024-987654",
            "firstName": "Emma",
            "lastName": "Williams",
            "dateOfBirth": "1990-03-22",
            "gender": "FEMALE",
            "nationalIdentifier": {
                "type": "NI_NUMBER",
                "value": "XX123456X"
            },
            "contactInformation": {
                "primaryPhone": "+44-20-7123-4567",
                "email": "emma.williams@email.co.uk",
                "preferredLanguage": "en-GB"
            },
            "address": {
                "street1": "45 Oxford Street",
                "city": "London",
                "postalCode": "W1D 1BS",
                "country": "UK"
            }
        },
        "incidentDetails": {
            "incidentDate": "2024-10-01T00:00:00Z",
            "incidentType": "ILLNESS",
            "incidentDescription": "Diagnosed with severe depression",
            "workRelated": False
        },
        "submissionMetadata": {
            "submittedBy": "test_user",
            "submissionTimestamp": datetime.utcnow().isoformat() + "Z",
            "channel": "WEB_PORTAL",
            "correlationId": str(uuid4())
        }
    }


# Health Check Tests
class TestHealthEndpoints:
    """Test health and status endpoints"""
    
    def test_root_endpoint(self):
        """Test API root endpoint"""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
        assert data["status"] == "operational"
    
    def test_health_endpoint(self):
        """Test health check endpoint"""
        response = client.get("/api/health")
        assert response.status_code == 200


# Authentication Tests
class TestAuthentication:
    """Test authentication and authorization"""
    
    def test_missing_token(self, sample_us_claim):
        """Test request without auth token"""
        response = client.post("/api/v1/claims/text", json=sample_us_claim)
        assert response.status_code == 401
    
    def test_invalid_token(self, sample_us_claim):
        """Test request with invalid token"""
        headers = {"Authorization": "Bearer invalid_token_here"}
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=headers
        )
        assert response.status_code == 401
    
    def test_insufficient_scope(self, sample_us_claim):
        """Test request with insufficient scopes"""
        token = create_access_token(
            data={
                "sub": "test_user_123",
                "scopes": ["claims:read"],  # Missing claims:write
                "client_id": "test_client"
            }
        )
        headers = {"Authorization": f"Bearer {token}"}
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=headers
        )
        assert response.status_code == 403


# Text-Based Claims Tests
class TestTextBasedClaims:
    """Test text-based claim submission"""
    
    def test_submit_valid_us_claim(self, sample_us_claim, auth_headers):
        """Test submitting valid US claim"""
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        assert response.status_code == 201
        data = response.json()
        assert "claimId" in data
        assert "claimNumber" in data
        assert "status" in data
        assert data["status"] in ["RECEIVED", "PROCESSING", "APPROVED", "UNDER_REVIEW"]
    
    def test_submit_valid_uk_claim(self, sample_uk_claim, auth_headers):
        """Test submitting valid UK claim"""
        response = client.post(
            "/api/v1/claims/text",
            json=sample_uk_claim,
            headers=auth_headers
        )
        assert response.status_code == 201
        data = response.json()
        assert "claimId" in data
        assert data["jurisdiction"] or True  # Claim processed
    
    def test_submit_invalid_claim_missing_required_fields(self, auth_headers):
        """Test submitting claim with missing required fields"""
        invalid_claim = {
            "claimType": "ACCIDENT",
            "jurisdiction": "US"
            # Missing policyHolder, incidentDetails, submissionMetadata
        }
        response = client.post(
            "/api/v1/claims/text",
            json=invalid_claim,
            headers=auth_headers
        )
        assert response.status_code == 422
        data = response.json()
        assert "error" in data
        assert data["error"]["code"] == "VALIDATION_ERROR"
    
    def test_submit_claim_invalid_date_format(self, sample_us_claim, auth_headers):
        """Test submitting claim with invalid date format"""
        sample_us_claim["policyHolder"]["dateOfBirth"] = "invalid-date"
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        assert response.status_code == 422
    
    def test_submit_claim_invalid_phone_number(self, sample_us_claim, auth_headers):
        """Test submitting claim with invalid phone number"""
        sample_us_claim["policyHolder"]["contactInformation"]["primaryPhone"] = "123"
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        assert response.status_code == 422


# OCR Claims Tests
class TestOCRClaims:
    """Test OCR-based claim submission"""
    
    def test_submit_pdf_document(self, auth_headers):
        """Test uploading PDF claim form"""
        files = {"file": ("claim.pdf", b"mock_pdf_content", "application/pdf")}
        data = {
            "documentType": "CLAIM_FORM",
            "jurisdiction": "US"
        }
        response = client.post(
            "/api/v1/claims/ocr",
            files=files,
            data=data,
            headers=auth_headers
        )
        # May fail without actual Azure setup, but tests endpoint
        assert response.status_code in [202, 500]
    
    def test_submit_invalid_file_type(self, auth_headers):
        """Test uploading invalid file type"""
        files = {"file": ("claim.exe", b"mock_content", "application/x-msdownload")}
        data = {
            "documentType": "CLAIM_FORM",
            "jurisdiction": "US"
        }
        response = client.post(
            "/api/v1/claims/ocr",
            files=files,
            data=data,
            headers=auth_headers
        )
        assert response.status_code == 400


# Claim Status Tests
class TestClaimStatus:
    """Test claim status retrieval"""
    
    def test_get_claim_status(self, auth_headers):
        """Test retrieving claim status"""
        claim_id = str(uuid4())
        response = client.get(
            f"/api/v1/claims/{claim_id}/status",
            headers=auth_headers
        )
        # Will return 404 for non-existent claim or 200 with mock data
        assert response.status_code in [200, 404]
    
    def test_get_claim_status_invalid_id(self, auth_headers):
        """Test retrieving status with invalid claim ID"""
        response = client.get(
            "/api/v1/claims/invalid-id/status",
            headers=auth_headers
        )
        assert response.status_code in [404, 422]


# Integration Tests
class TestEndToEndFlow:
    """Test complete claim submission workflow"""
    
    def test_complete_us_claim_flow(self, sample_us_claim, auth_headers):
        """Test end-to-end US claim submission"""
        
        # 1. Submit claim
        submit_response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        
        if submit_response.status_code == 201:
            claim_data = submit_response.json()
            claim_id = claim_data["claimId"]
            
            # 2. Check status
            status_response = client.get(
                f"/api/v1/claims/{claim_id}/status",
                headers=auth_headers
            )
            
            assert status_response.status_code in [200, 404]


# Performance Tests
class TestPerformance:
    """Test API performance and rate limiting"""
    
    def test_rate_limiting(self, sample_us_claim, auth_headers):
        """Test rate limiting on text claims endpoint"""
        # Submit multiple requests rapidly
        responses = []
        for _ in range(5):
            response = client.post(
                "/api/v1/claims/text",
                json=sample_us_claim,
                headers=auth_headers
            )
            responses.append(response.status_code)
        
        # Should get mix of 201 and 429 (rate limited)
        assert any(code in [201, 500] for code in responses)


# Data Validation Tests
class TestDataValidation:
    """Test comprehensive data validation"""
    
    def test_validate_ssn_format(self, sample_us_claim, auth_headers):
        """Test SSN validation"""
        sample_us_claim["policyHolder"]["nationalIdentifier"]["value"] = "invalid-ssn"
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        # Should still accept as it's masked format
        assert response.status_code in [201, 422]
    
    def test_validate_currency_code(self, sample_us_claim, auth_headers):
        """Test currency code validation"""
        sample_us_claim["financialInformation"] = {
            "claimedAmount": {
                "amount": 5000,
                "currency": "INVALID"  # Should be USD or GBP
            }
        }
        response = client.post(
            "/api/v1/claims/text",
            json=sample_us_claim,
            headers=auth_headers
        )
        assert response.status_code == 422


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--cov=app", "--cov-report=html"])
